# Kubernetes v1.32 三主离线工程：Ubuntu 22.04 + HaVIP

默认是 **三台 Ubuntu Server 22.04 LTS / x86_64**，每台同时运行控制平面、一个本地 etcd 成员和业务 Pod。通过自建 **HAProxy + Keepalived 单播 VRRP** 管理用户已创建并关联三台云主机的 **192.168.0.62**。Kubernetes API 统一入口为 **192.168.0.62:8443**；HAProxy 转发至三台节点各自的 **6443**，全程 TCP/TLS 透传。

**这是源工程，未包含二进制、Deb、wheel 和镜像。** 必须先在联网的同版 Ubuntu 准备机下载生成完整包，再转入离线区。目标不在线安装依赖，不使用在线 Galaxy/CNI 清单或镜像拉取。

## 适用范围与维护状态

本包保留你的 Kubernetes v1.32 要求，默认 kubeadm/kubelet/kubectl **v1.32.13**、containerd **1.7.36**、runc **1.3.4**、crictl **v1.32.0**、reference CNI plugins **1.7.1**、Flannel **v0.28.4**、Ansible-core **2.17.14**。pause **3.10**、etcd **3.5.24-0**、CoreDNS **v1.11.3** 由实际 v1.32.13 kubeadm 导出并核对。

截至 2026-10-20，Kubernetes 1.32 已于 2026-02-28 EOL，containerd 1.7 已于 2026-09-30 EOL。三主架构不会延长旧版本的支持期限。本工程适用于明确要求该版本的环境，不把这些版本称为当前受支持的生产组合。[Kubernetes 状态](https://kubernetes.io/releases/1.32/) · [containerd 维护矩阵](https://github.com/containerd/containerd/blob/main/RELEASES.md)

目标及准备/控制端都要求标准 Ubuntu 22.04 amd64、系统 Python 3.10、systemd、内核 >=5.15、统一 cgroup v2。每个目标至少 2 vCPU/2 GiB、安装前 /var/lib 空闲 >=20 GiB；混合业务建议按负载增加资源并为 etcd 使用可靠低延迟 SSD。运行内核须有 overlay/br_netfilter 模块。不是跨任意全新发行版的通用离线介质。

这是三节点**全新集群**安装，不自动把已初始化的单节点集群扩容迁移。旧单节点 lock 缺少 HA 依赖和拓扑声明，HA 工程会拒绝混用。若曾用旧包初始化，应先保全数据并选择明确的迁移/重建流程；不要覆盖旧状态目录。

## 1. 修改自己的三个节点地址

源包中的 `inventory.ini` 是模板。**192.0.2.11/12/13 是文档示例地址，必须替换**。完整物料包只带 inventory.example.ini，解压后先复制成 inventory.ini。

```ini
[control_plane]
master1 ansible_host=192.0.2.11 kube_node_ip=192.0.2.11
master2 ansible_host=192.0.2.12 kube_node_ip=192.0.2.12
master3 ansible_host=192.0.2.13 kube_node_ip=192.0.2.13

[all:vars]
ansible_user=root
ansible_python_interpreter=/usr/bin/python3
```

每行的 ansible_host 和 kube_node_ip 改为该机器实际固定内网 IP。inventory 名称就是 Kubernetes 节点名称；首行是唯一执行 init 的 bootstrap master，其余两行按顺序 join。不要在初始化后重排三行或修改节点名/IP。

可从独立的 Ubuntu 22.04 控制端执行，也可以直接在 master1 执行。如果在 master1 上执行，给 master1 这一行额外添加 `ansible_connection=local`，其他两台继续走 SSH。提前从控制端用实际 SSH 用户登录并核验各主机密钥，准备密钥和 sudo。ansible_user 可改为 ubuntu 等用户，不要把密码或私钥放进物料包。

## 2. HaVIP 与网段配置

编辑 `config/cluster.yml`：

```yaml
ha_vip: 192.168.0.62
ha_vip_prefix: 32
ha_api_port: 8443
ha_router_id: 62
ha_cloud_havip_associated: true
ha_interface: ''
allow_control_plane_workloads: true
pod_cidr: 10.244.0.0/16
service_cidr: 10.96.0.0/12
cluster_dns: 10.96.0.10
```

用户已确认云平台创建并关联三台云主机，因此关联前提默认 true；该变量是记录这项外部事实，不会代你调用云 API。平台名称未提供，本工程不能审计其控制台状态或特有安全组限制。若换了机器/HaVIP，应重新完成实际关联。HaVIP 必须与三台主 IP 不同，并属于平台允许关联的网络范围。

默认从各节点 kube_node_ip 自动找到网卡。如果需要指定，统一网卡名填 ha_interface；各节点网卡名不同则在对应 inventory 行写 `node_ha_interface=ens3`。VRRP 使用单播，自动把另外两台 IP 写入各自 unicast_peer。优先级为 150/140/130，全部从 BACKUP 启动并设置 nopreempt，减少恢复后的无谓抢占。ha_router_id 必须与同网络其他 VRRP 组区分。

Pod/Service 网段必须与三台主机、HaVIP、VPN/现有路由无重叠；改 Service CIDR 时 cluster_dns 保持为其网络地址 +10。默认 CoreDNS 仅解析集群域名；若要解析外部名称，在 coredns_upstream_dns 配置可达的内网 IPv4 DNS。

必须先按 [运维说明](docs/OPERATIONS.md) 配置云安全组和已有主机防火墙，包括三节点间 **IP 协议 112（VRRP，不是 UDP 112）**。安装器不自动关闭防火墙。若主机有防火墙规则，审核处理后再设置 firewall_rules_acknowledged: true。

## 3. 联网准备：国内入口 + 已验证 SOCKS5 代理

使用另一台/临时 Ubuntu 22.04 amd64 准备机，与目标保持兼容的系统包基线。把源工程解压到 `/opt/k8s-offline-ubuntu2204-ha`：

```bash
cd /opt/k8s-offline-ubuntu2204-ha
sudo env K8S_PREPARE_PROXY=socks5h://172.16.0.41:8080 bash scripts/prepare.sh
cat artifacts/lock.yml
cat artifacts/debs/manifest.tsv
cat artifacts/images/manifest.tsv
sudo bash scripts/package.sh /opt/k8s-offline-ubuntu22-ha-amd64.tar.gz
```

Ubuntu/PyPI 默认阿里云，二进制及校验文件、容器镜像默认 DaoCloud。下载入口可在 config/downloads.env 修改。代理只作用于联网准备进程；APT、pip、curl、skopeo 分别正确传入代理，不写入 Kubernetes/systemd 服务。已确认的网络证据仅是代理访问阿里云 jammy InRelease 得到 HTTP 200；其他入口及全部版本仍须本次实际下载确认。[代理实现](docs/PROXY_PREPARATION.md) · [国内入口与信任边界](docs/CHINA_DOWNLOADS.md)

HAProxy、Keepalived、procps 及传递依赖由签名 Ubuntu APT 仓库真实下载，所有精确包版本、URL、SHA 写入 debs/manifest.tsv；lock.yml 的 load_balancer_versions 记录实际 HAProxy/Keepalived 版本。可在 config/versions.env 用 HAPROXY_DEB_VERSION、KEEPALIVED_DEB_VERSION 预先指定完整 Debian revision；空值表示解析并锁定准备时仓库候选。不会在源工程里编造永久有效的 OS 依赖表。

镜像仍按 kubeadm/Flannel 原始完整名称打包，导入 containerd 的 k8s.io namespace；不用把 IMAGE_REPOSITORY 改成加速器域名。镜像数不因三主而变成三倍下载，但完整包必须分别导入三台。版本/下载配置更改或准备失败后，请在新的源工程副本中重新准备，拒绝半成品混装。[完整下载清单](docs/DOWNLOADS.md)

## 4. 转入离线区并补齐三个目标的依赖

把上一步完整 tar 和 tar.sha256 转入控制端（可用 master1），不是本次小型源包：

```bash
cd /opt
sha256sum -c k8s-offline-ubuntu22-ha-amd64.tar.gz.sha256
sudo tar -xzf k8s-offline-ubuntu22-ha-amd64.tar.gz
cd /opt/k8s-offline-ubuntu2204-ha
sudo bash scripts/bootstrap_offline.sh
sudo cp inventory.example.ini inventory.ini
sudoedit inventory.ini config/cluster.yml
```

本地 bootstrap 仅使用空 APT 源 + --no-download，以及 pip --no-index --require-hashes。控制端 bootstrap 完成后，再由 Ansible 复制完整物料并离线补齐三台依赖：

```bash
sudo .venv/bin/ansible-playbook -i inventory.ini playbooks/bootstrap.yml
```

bootstrap.yml 依赖目标标准安装已自带 Python 3.10 和包管理器。它会将 artifacts/config/scripts 复制到各节点 /var/lib/k8s-ha-bootstrap，再在本机执行离线 bootstrap；不会 SSH 出去访问任何下载站。转移体积较大，控制端和目标须有足够空间。目标已有更高版本系统包时拒绝降级，应重新制作匹配的包。系统包补齐后建议逐台重启并恢复 SSH，再执行安装；工程不自动替换内核或重启。

## 5. 三主安装与初始化

```bash
sudo .venv/bin/ansible-playbook -i inventory.ini playbooks/site.yml
```

安装顺序是：所有节点只读预检查与 SHA → 保存原始文件/服务/swap/sysctl → 三台安装 containerd/runc/CNI/CRI/Kubernetes 并导入全部镜像 → 部署原生 HAProxy/Keepalived、配置检查和开机自启 → 确认 HaVIP 可达且恰好一个 owner → 只在 master1 init 并本地应用 Flannel/CoreDNS → 生成短时 join token、从内存分发必要共享 CA/SA 密钥 → master2 和 master3 **serial: 1** 加入控制平面/etcd → 删除本次 join token → 验证全部节点、etcd 与跨节点网络。

init 和 join 均用 kubeadm v1beta4，imagePullPolicy: Never；containerd/kubelet 均用 systemd cgroup。join 使用真实 CA discovery hash，不跳过 CA 校验；只共享官方规定的 CA/SA 材料，节点 API/etcd 证书由 kubeadm 为各自地址生成。含 token/私钥的任务 no_log，临时 join.yml 在 always 中删除，共享材料不写控制端持久文件。

每次安装保留拓扑/地址/版本指纹。不一致会停止；同配置可重跑已完成部分。admin.conf 与成功标记不一致时停止并保留现场，不猜测部分 etcd 加入阶段是否可以重复。这里提供完整重建回滚，单个成员修复/迁移需单独制定步骤。

## 6. 验证、切换和重启

```bash
sudo .venv/bin/ansible-playbook -i inventory.ini playbooks/verify.yml
sudo .venv/bin/ansible-playbook -i inventory.ini playbooks/failover.yml
```

verify 会检查三台直连 API、通过 HaVIP 的 Ready 状态、各机 CRI 和四个开机服务、恰好三个控制平面节点、三成员同一 etcd 集群且全部是 voter 并共享有效 leader、Flannel/kube-proxy/CoreDNS。之后每台创建一个 server 和 client，所有 client 访问所有 server Pod IP、ClusterIP 和集群 DNS，最后清理测试 namespace。

failover 是独立验收入口：正常检查后停止当前 HaVIP owner 的 HAProxy，等待 Keepalived track_script 切换，要求 owner 改变且 API /readyz 成功，并在 always 中恢复原 HAProxy。通过后写 /var/lib/k8s-offline/failover-verified.json。它验证的是这一路径的进程故障切换，不能当作三台云主机断电、分区、存储或整可用区故障全部验收通过。

手工逐台重启时，每次等该机和三个 etcd voter 恢复健康后再重启下一台。三成员 etcd 只能容忍一个成员失效；同时停两台会丢失多数派。业务应用自身副本、存储、Ingress/Service 外部入口需要各自设计，HaVIP 在此只服务 Kubernetes API。

## 7. 基础回滚（整个三节点集群）

先保全必要 etcd、PKI 和业务数据。以下会销毁整个集群，不能用 --limit 针对单台执行：

```bash
sudo .venv/bin/ansible-playbook -i inventory.ini playbooks/rollback.yml \
  -e rollback_confirm=true -e destroy_cluster_data=true
```

回滚按节点串行执行，跳过 etcd 成员移除阶段，因为这是所有节点都要清空的整集群拆除；不把它用于保留集群的单节点退役。停止 HAProxy/Keepalived/kubelet/runtime，删除受管集群数据并恢复首次备份的主机文件、服务/swap/sysctl；保留备份、物料、OS 包和报告。不会删除云 HaVIP 资源或解除控制台关联，不恢复应用卷。完成后逐台重启，按运维说明归档旧状态再重建。[运维与回滚细节](docs/OPERATIONS.md)

## 交付验证范围

本次在 macOS 的 Python 3.13 / Ansible-core 2.18.6 做本地检查；默认实际离线工具链仍是 Ubuntu Python 3.10 / Ansible 2.17.14。已做的检查与必须现场执行的内容见 [VALIDATION.md](docs/VALIDATION.md)。未声称已在你的三台云主机安装或切换成功，源包也没有包含全部大型下载物料。
