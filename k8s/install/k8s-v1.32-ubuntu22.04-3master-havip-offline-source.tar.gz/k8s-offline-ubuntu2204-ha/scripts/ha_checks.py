#!/usr/bin/env python3
"""Pure topology checks and read-only host/etcd validation, using stdlib only."""
import ipaddress
import json
import re
import subprocess
import sys


def ipv4(value):
    address = ipaddress.IPv4Address(value)
    if address.is_loopback or address.is_unspecified or address.is_multicast or address.is_link_local:
        raise ValueError('Use stable unicast IPv4 addresses')
    if any(address in ipaddress.IPv4Network(net) for net in ('192.0.2.0/24','198.51.100.0/24','203.0.113.0/24')):
        raise ValueError('Replace documentation-example IP addresses in inventory.ini')
    return address


def topology(data):
    nodes = [ipv4(v) for v in data['nodes']]
    names = data['names']
    vip = ipv4(data['vip'])
    if len(nodes) != 3 or len(set(nodes)) != 3 or len(names) != 3 or len(set(names)) != 3:
        raise ValueError('Exactly three distinct control-plane node names and IPs are required')
    if not all(re.fullmatch(r'[a-z0-9]([-a-z0-9]*[a-z0-9])?', n) and len(n) <= 63 for n in names):
        raise ValueError('Inventory node names must be valid Kubernetes DNS labels')
    if vip in nodes:
        raise ValueError('HaVIP must differ from every primary node IP')
    pod, service = [ipaddress.IPv4Network(data[k], strict=True) for k in ('pod_cidr','service_cidr')]
    if pod.overlaps(service) or any(ip in net for ip in nodes + [vip] for net in (pod,service)):
        raise ValueError('Pod/Service networks must not overlap each other, HaVIP, or node IPs')
    if not 1024 <= int(data['port']) <= 65535 or int(data['port']) == 6443:
        raise ValueError('HAProxy must use a distinct frontend port, e.g. 8443, not kube-apiserver port 6443')
    if not 1 <= int(data['router_id']) <= 255 or not 1 <= int(data['prefix']) <= 32:
        raise ValueError('Invalid VRRP router ID or VIP prefix')
    return {'nodes': [str(n) for n in nodes], 'vip': str(vip), 'endpoint': str(vip)+':'+str(data['port'])}


def local(node, vip, interface):
    ipv4(node); ipv4(vip)
    if not re.fullmatch(r'[A-Za-z0-9_.:-]{1,15}', interface):
        raise ValueError('Invalid node interface name')
    links = json.loads(subprocess.check_output(['ip','-j','-4','address','show','dev',interface],text=True))
    if len(links) != 1 or 'UP' not in links[0].get('flags',[]):
        raise ValueError('Selected HaVIP interface is missing or down')
    ips = [a['local'] for a in links[0].get('addr_info',[]) if a.get('family') == 'inet']
    if node not in ips:
        raise ValueError('The selected HaVIP interface must own kube_node_ip')
    if vip not in ips:
        routes = json.loads(subprocess.check_output(['ip','-j','-4','route','get',vip],text=True))
        if not routes or routes[0].get('dev') != interface:
            raise ValueError('HaVIP route must use the selected node interface')
    return {'interface':interface,'node_ip':node,'vip':vip}


def etcd(status, members, expected_names):
    roster = members.get('members',[])
    if len(roster) != 3 or {m.get('name') for m in roster} != set(expected_names):
        raise ValueError('etcd must contain exactly the three expected named members')
    if any(m.get('isLearner',False) for m in roster):
        raise ValueError('All three etcd members must be promoted voting members')
    if len(status) != 3 or len({s['Endpoint'] for s in status}) != 3:
        raise ValueError('etcd status must contain three distinct endpoints')
    states = [s['Status'] for s in status]
    cluster_ids = {s['header']['cluster_id'] for s in states}
    member_ids = {s['header']['member_id'] for s in states}
    leaders = {s.get('leader',0) for s in states}
    if len(cluster_ids) != 1 or len(member_ids) != 3 or member_ids != {m['ID'] for m in roster}:
        raise ValueError('etcd members/status must refer to the same three-member cluster')
    if len(leaders) != 1 or next(iter(leaders)) not in member_ids or any(s.get('errors') for s in states):
        raise ValueError('etcd must agree on a live leader and report no errors')
    return {'members':sorted(expected_names),'healthy_leader':next(iter(leaders))}


def main():
    action,*args = sys.argv[1:]
    if action == 'topology': result = topology(json.loads(args[0]))
    elif action == 'local': result = local(*args)
    elif action == 'etcd': result = etcd(json.loads(args[0]),json.loads(args[1]),json.loads(args[2]))
    else: raise ValueError('Unknown HA check action')
    print(json.dumps(result))

if __name__ == '__main__':
    try: main()
    except (ValueError,KeyError,OSError,subprocess.CalledProcessError) as exc:
        sys.exit('HA validation failed: '+str(exc))
