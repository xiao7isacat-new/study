#!/usr/bin/env python3
"""Render the pinned upstream Flannel manifest on the Ansible controller (PyYAML)."""
import argparse
import ipaddress
import json
from pathlib import Path
import sys
import yaml


def render(documents, pod_cidr, iface):
    network = ipaddress.IPv4Network(pod_cidr, strict=True)
    if not iface or any(c.isspace() for c in iface):
        raise ValueError("Flannel iface must be one interface name or node IPv4 address")
    maps = daemonsets = 0
    for doc in documents:
        if not isinstance(doc, dict):
            continue
        name = doc.get("metadata", {}).get("name")
        if doc.get("kind") == "ConfigMap" and name == "kube-flannel-cfg":
            conf = json.loads(doc["data"]["net-conf.json"])
            conf["Network"] = str(network)
            if conf.get("Backend", {}).get("Type") != "vxlan":
                raise ValueError("Only the pinned VXLAN Flannel backend is supported")
            doc["data"]["net-conf.json"] = json.dumps(conf, indent=2) + "\n"
            maps += 1
        if doc.get("kind") == "DaemonSet" and name == "kube-flannel-ds":
            spec = doc["spec"]["template"]["spec"]
            for container in spec.get("initContainers", []) + spec.get("containers", []):
                if not container.get("image"):
                    raise ValueError("Flannel container is missing an image")
                container["imagePullPolicy"] = "Never"
            containers = [c for c in spec["containers"] if c["name"] == "kube-flannel"]
            if len(containers) != 1:
                raise ValueError("Expected one kube-flannel container")
            args = containers[0].setdefault("args", [])
            args[:] = [a for a in args if not a.startswith("--iface=")]
            args.append("--iface=" + iface)
            daemonsets += 1
    if maps != 1 or daemonsets != 1:
        raise ValueError("Upstream manifest layout changed: expected one Flannel ConfigMap and DaemonSet")
    return documents


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for flag in ("source", "output", "pod-cidr", "iface"):
        p.add_argument("--" + flag, required=True)
    args = p.parse_args()
    try:
        docs = list(yaml.safe_load_all(Path(args.source).read_text()))
        result = yaml.safe_dump_all(render(docs, args.pod_cidr, args.iface), sort_keys=False)
        Path(args.output).write_text(result)
    except (OSError, ValueError, KeyError, yaml.YAMLError) as exc:
        print(f"Flannel rendering failed: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
