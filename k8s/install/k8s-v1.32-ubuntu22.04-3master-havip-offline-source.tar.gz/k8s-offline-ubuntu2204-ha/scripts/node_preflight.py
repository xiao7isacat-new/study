#!/usr/bin/env python3
"""Read-only IPv4 checks; depends only on Python stdlib and iproute2 on the node."""
import argparse
import ipaddress
import json
import pathlib
import subprocess
import sys


def check(node_ip, pod_cidr, service_cidr, cluster_dns, addresses, routes, managed=False):
    node = ipaddress.IPv4Address(node_ip)
    pod = ipaddress.IPv4Network(pod_cidr, strict=True)
    service = ipaddress.IPv4Network(service_cidr, strict=True)
    dns = ipaddress.IPv4Address(cluster_dns)
    if node.is_loopback or node.is_link_local or node.is_unspecified or node.is_multicast:
        raise ValueError("node IP must be a stable unicast IPv4 address")
    if not 8 <= pod.prefixlen <= 24:
        raise ValueError("Pod CIDR must have prefix /8 through /24 (default per-node /24)")
    if not 12 <= service.prefixlen <= 27:
        raise ValueError("Service CIDR must have prefix /12 through /27")
    if pod.overlaps(service) or node in pod or node in service:
        raise ValueError("Pod/Service CIDRs must not overlap each other or the node IP")
    if dns not in service or dns in (service.network_address, service.broadcast_address,
                                     service.network_address + 1):
        raise ValueError("cluster_dns must be a usable Service IP other than the API Service's first IP")
    if dns != service.network_address + 10:
        raise ValueError("cluster_dns must equal the Service network address + 10 (kubeadm CoreDNS Service)")
    found = []
    own_links = {"cni0", "flannel.1"} if managed else set()
    for link in addresses:
        iface = link.get("ifname", "").split("@")[0]
        for addr in link.get("addr_info", []):
            if addr.get("family") != "inet":
                continue
            ip = ipaddress.IPv4Address(addr["local"])
            network = ipaddress.IPv4Network(f'{ip}/{addr["prefixlen"]}', strict=False)
            if ip == node and iface != "lo":
                if "UP" not in link.get("flags", []):
                    raise ValueError(f"node interface {iface} is down")
                found.append(iface)
            if iface not in own_links and not ip.is_loopback:
                for selected in (pod, service):
                    if selected.overlaps(network):
                        raise ValueError(f"{selected} overlaps local network {network} on {iface}")
    if len(found) != 1:
        raise ValueError(f"node IP must occur on exactly one local interface; found {found}")
    for route in routes:
        dst = route.get("dst", "default")
        if dst == "default" or ":" in dst:
            continue
        network = ipaddress.IPv4Network(dst, strict=False)
        if network.prefixlen == 0:
            continue
        dev = route.get("dev", "").split("@")[0]
        if managed and dev in own_links and network.subnet_of(pod):
            continue
        # local table loopback routes cannot overlap valid private defaults anyway.
        for selected in (pod, service):
            if selected.overlaps(network):
                raise ValueError(f"{selected} overlaps existing route {network} on {dev}")
    return {"node_ip": str(node), "interface": found[0], "pod_cidr": str(pod),
            "service_cidr": str(service), "cluster_dns": str(dns)}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for flag in ("node-ip", "pod-cidr", "service-cidr", "cluster-dns"):
        p.add_argument("--" + flag, required=True)
    args = p.parse_args()
    try:
        addresses = json.loads(subprocess.check_output(["ip", "-j", "-4", "address", "show"], text=True))
        routes = json.loads(subprocess.check_output(["ip", "-j", "-4", "route", "show", "table", "all"], text=True))
        managed = pathlib.Path("/var/lib/k8s-offline/cluster-fingerprint.sha256").is_file()
        print(json.dumps(check(args.node_ip, args.pod_cidr, args.service_cidr,
                               args.cluster_dns, addresses, routes, managed)))
    except (ValueError, KeyError, OSError, subprocess.CalledProcessError) as exc:
        print(f"Network preflight failed: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
