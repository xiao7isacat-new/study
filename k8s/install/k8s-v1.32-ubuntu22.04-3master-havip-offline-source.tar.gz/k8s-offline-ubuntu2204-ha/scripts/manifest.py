#!/usr/bin/env python3
"""Bundle metadata and integrity helpers; verification uses Python stdlib only."""
import csv
import email
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import sys
import urllib.parse
import zipfile
import download_sources


def run(args):
    return subprocess.check_output(args, text=True).strip()


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def table(path, fields, rows):
    with Path(path).open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def download(url, destination):
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name(destination.name + ".partial")
    effective_url = subprocess.check_output([
        "curl", "-q", *download_sources.curl_proxy_args(), "--ipv4", "--fail", "--location", "--retry", "2", "--connect-timeout", "15",
        "--max-time", "900", "--proto", "=https", "--proto-redir", "=https", "--tlsv1.2",
        "--write-out", "%{url_effective}", "--output", str(temporary), url], text=True).strip()
    if not effective_url.startswith("https://"):
        raise RuntimeError("Download did not finish over HTTPS")
    temporary.replace(destination)
    return effective_url


def checksum_from_file(path, asset_name):
    content = Path(path).read_text().strip()
    if re.fullmatch(r"[0-9a-fA-F]{64}", content):
        return content.lower()
    for line in content.splitlines():
        match = re.fullmatch(r"([0-9a-fA-F]{64})\s+\*?(\S+)", line.strip())
        if match and Path(match.group(2)).name == asset_name:
            return match.group(1).lower()
    raise RuntimeError(f"No SHA256 for {asset_name} in {path}")


def downloads(root):
    env = os.environ
    rows = []

    def fetch(relative, url, version, checksum_url=None, upstream_name=None):
        destination = root / relative
        actual_url = download_sources.file_url(url)
        effective_url = download(actual_url, destination)
        digest = sha(destination)
        verification = "HTTPS + locally recorded SHA256 (TOFU; no upstream checksum)"
        actual_checksum_url = ""
        if checksum_url:
            checksum_path = root / "downloads/checksums" / (destination.name + ".sha256.txt")
            actual_checksum_url = download_sources.file_url(checksum_url)
            download(actual_checksum_url, checksum_path)
            expected = checksum_from_file(checksum_path, upstream_name or url.rsplit("/", 1)[1])
            if expected != digest:
                raise RuntimeError(f"Checksum mismatch: {actual_url}")
            verification = "upstream-format SHA256 sidecar via configured mirror; no independent origin/signature verification"
        rows.append(dict(path=relative, version=version, url=actual_url, effective_url=effective_url,
                         official_url=url, checksum_url=actual_checksum_url,
                         official_checksum_url=checksum_url or "", sha256=digest, verification=verification))

    k = env["KUBERNETES_VERSION"]
    for binary in ("kubeadm", "kubelet", "kubectl"):
        url = f"https://dl.k8s.io/release/{k}/bin/linux/amd64/{binary}"
        fetch(f"bin/{binary}", url, k, url + ".sha256")
    v = env["CONTAINERD_VERSION"].lstrip("v")
    url = f"https://github.com/containerd/containerd/releases/download/v{v}/containerd-{v}-linux-amd64.tar.gz"
    fetch("downloads/containerd.tar.gz", url, v, url + ".sha256sum")
    v = env["RUNC_VERSION"].lstrip("v")
    base = f"https://github.com/opencontainers/runc/releases/download/v{v}"
    fetch("downloads/runc.amd64", base + "/runc.amd64", v, base + "/runc.sha256sum")
    v = env["CNI_PLUGINS_VERSION"].lstrip("v")
    url = f"https://github.com/containernetworking/plugins/releases/download/v{v}/cni-plugins-linux-amd64-v{v}.tgz"
    fetch("downloads/cni-plugins.tgz", url, v, url + ".sha256")
    v = "v" + env["CRICTL_VERSION"].lstrip("v")
    url = f"https://github.com/kubernetes-sigs/cri-tools/releases/download/{v}/crictl-{v}-linux-amd64.tar.gz"
    fetch("downloads/crictl.tar.gz", url, v, url + ".sha256")
    v = "v" + env["FLANNEL_VERSION"].lstrip("v")
    url = f"https://github.com/flannel-io/flannel/releases/download/{v}/kube-flannel.yml"
    fetch("manifests/kube-flannel.yml", url, v)
    table(root / "downloads/manifest.tsv", ["path", "version", "url", "effective_url", "official_url", "checksum_url", "official_checksum_url", "sha256", "verification"], rows)


def apt_options(work):
    return ["-o", f"Dir::Etc::sourcelist={work}/sources.list", "-o", f"Dir::Etc::sourceparts={work}/empty-config",
            "-o", "Dir::Etc::preferences=/dev/null", "-o", f"Dir::Etc::preferencesparts={work}/empty-config",
            "-o", f"Dir::State::lists={work}/lists", "-o", f"Dir::State::status={work}/status",
            "-o", "APT::Architecture=amd64", "-o", "APT::Sandbox::User=root"]


def parse_deb822(text):
    result = {}
    key = None
    for line in text.splitlines():
        if line.startswith(" ") and key:
            result[key] += "\n" + line
        elif ": " in line:
            key, value = line.split(": ", 1)
            result[key] = value
    return result


def debs(root, work):
    rows = []
    for path in sorted(root.glob("*.deb")):
        fields = parse_deb822(run(["dpkg-deb", "--field", str(path)]))
        name, version, arch = (fields[field] for field in ("Package", "Version", "Architecture"))
        if arch not in ("amd64", "all"):
            raise RuntimeError(f"Wrong architecture: {path}")
        raw = run(["apt-cache", *apt_options(work), "show", f"{name}={version}"])
        records = [parse_deb822(part) for part in raw.split("\n\n")]
        digest = sha(path)
        matching = [record for record in records if record.get("SHA256") == digest
                    and record.get("Version") == version and record.get("Architecture") == arch]
        if not matching:
            raise RuntimeError(f"No authenticated APT SHA256 metadata matches {path}")
        metadata = matching[0]
        raw_uris = run(["apt-get", *apt_options(work), "--print-uris", "download", f"{name}={version}"])
        urls = [shlex.split(line)[0] for line in raw_uris.splitlines() if line.startswith("'")]
        urls = [url for url in urls if download_sources.apt_url_allowed(url)
                and urllib.parse.unquote(url).endswith(urllib.parse.unquote(metadata["Filename"]))]
        if not urls:
            raise RuntimeError(f"No configured Ubuntu mirror URL resolved for {name}={version}")
        rows.append(dict(file=path.name, package=name, version=version, arch=arch, url=urls[0], sha256=digest))
    if not rows:
        raise RuntimeError("No .deb files produced")
    table(root / "manifest.tsv", ["file", "package", "version", "arch", "url", "sha256"], rows)


def wheels(root):
    rows = []
    for path in sorted(root.glob("*.whl")):
        with zipfile.ZipFile(path) as archive:
            metadata_path, = [name for name in archive.namelist() if name.endswith(".dist-info/METADATA")]
            metadata = email.message_from_bytes(archive.read(metadata_path))
        name, version = metadata["Name"], metadata["Version"]
        index_url = download_sources.wheel_index_url(name)
        metadata_path = root / "index-metadata" / (re.sub(r"[-_.]+", "-", name).lower() + ".html")
        download(index_url, metadata_path)
        digest = sha(path)
        url = download_sources.wheel_record(metadata_path.read_text(), index_url, path.name, digest)
        rows.append(dict(file=path.name, package=name, version=version, url=url, index_url=index_url, sha256=digest))
    if not rows:
        raise RuntimeError("No mirrored wheels produced")
    table(root / "manifest.tsv", ["file", "package", "version", "url", "index_url", "sha256"], rows)
    (root / "requirements.lock").write_text("".join(
        f"{row['package']}=={row['version']} --hash=sha256:{row['sha256']}\n" for row in rows))


CONFIG_KEYS = {
    "KUBERNETES_VERSION": "kubernetes_version", "CONTAINERD_VERSION": "containerd_version",
    "RUNC_VERSION": "runc_version", "CNI_PLUGINS_VERSION": "cni_plugins_version",
    "CRICTL_VERSION": "crictl_version", "FLANNEL_VERSION": "flannel_version",
    "ANSIBLE_CORE_VERSION": "ansible_core_version", "IMAGE_REPOSITORY": "image_repository",
    "SMOKE_IMAGE": "smoke_image",
}


def lock(root):
    images = json.loads((root / "images/manifest.json").read_text())
    kubeadm_images = (root / "manifests/kubeadm-images.txt").read_text().splitlines()
    pause, = [image for image in kubeadm_images if image.rsplit("/", 1)[-1].startswith("pause:")]
    data = dict(schema_version=1, os_id="ubuntu", os_version="22.04", arch="amd64", pause_image=pause,
                images=images, kubeadm_images=kubeadm_images,
                image_archive_format="docker-archive; original tags retained; manifest media conversion may change imported digest")
    data.update({value: os.environ[key] for key, value in CONFIG_KEYS.items()})
    data["download_sources"] = download_sources.settings()
    data["topology"] = "three-control-plane-ha"
    data["required_os_packages"] = ["haproxy", "keepalived", "procps"]
    with (root / "debs/manifest.tsv").open() as stream:
        packages = {r["package"]: r["version"] for r in csv.DictReader(stream, delimiter="\t")}
    data["load_balancer_versions"] = {name: packages[name] for name in ("haproxy", "keepalived")}
    # JSON is a strict YAML subset; stdlib verification works before PyYAML is installed.
    (root / "lock.yml").write_text(json.dumps({"offline_lock": data}, indent=2) + "\n")
    (root / "versions.env").write_text((root.parent / "config/versions.env").read_text())
    (root / "downloads.env").write_bytes((root.parent / "config/downloads.env").read_bytes())


def sums(root):
    files = sorted(path for path in root.rglob("*") if path.is_file() and path.name != "SHA256SUMS")
    if any(path.is_symlink() for path in root.rglob("*")):
        raise RuntimeError("Artifact symlinks are not allowed")
    (root / "SHA256SUMS").write_text("".join(f"{sha(path)}  {path.relative_to(root)}\n" for path in files))


def verify(root):
    listed = set()
    for line in (root / "SHA256SUMS").read_text().splitlines():
        digest, relative = line.split("  ", 1)
        path = root / relative
        if not re.fullmatch(r"[0-9a-f]{64}", digest) or Path(relative).is_absolute() or ".." in Path(relative).parts:
            raise RuntimeError("Invalid checksum manifest entry")
        if path.is_symlink() or not path.is_file() or sha(path) != digest:
            raise RuntimeError(f"Artifact checksum mismatch: {relative}")
        listed.add(relative)
    actual = {str(path.relative_to(root)) for path in root.rglob("*") if path.is_file() and path.name != "SHA256SUMS"}
    if actual != listed or any(path.is_symlink() for path in root.rglob("*")):
        raise RuntimeError("Extra/missing artifact files or symlinks detected")
    data = json.loads((root / "lock.yml").read_text())["offline_lock"]
    if (data["schema_version"], data["os_id"], data["os_version"], data["arch"]) != (1, "ubuntu", "22.04", "amd64"):
        raise RuntimeError("Unsupported lock schema/platform")
    if data.get("topology") != "three-control-plane-ha" or set(data.get("load_balancer_versions", {})) != {"haproxy", "keepalived"}:
        raise RuntimeError("HA bundle with locked haproxy/keepalived versions is required; single-node material cannot be reused")
    if (root / "versions.env").read_bytes() != (root.parent / "config/versions.env").read_bytes():
        raise RuntimeError("config/versions.env changed after preparation; prepare a new bundle")
    if "download_sources" in data and (root / "downloads.env").read_bytes() != (root.parent / "config/downloads.env").read_bytes():
        raise RuntimeError("config/downloads.env changed after preparation; prepare a new bundle")
    required = ["bin/kubeadm", "bin/kubelet", "bin/kubectl", "downloads/containerd.tar.gz", "downloads/runc.amd64",
                "downloads/cni-plugins.tgz", "downloads/crictl.tar.gz", "manifests/kube-flannel.yml",
                "debs/manifest.tsv", "wheels/requirements.lock"]
    required.extend(image["archive"] for image in data["images"])
    if not data["images"] or any(not (root / relative).is_file() for relative in required):
        raise RuntimeError("Incomplete prepared bundle")
    for image in data["images"]:
        if image["archive_sha256"] != sha(root / image["archive"]) or not re.fullmatch(r"sha256:[0-9a-f]{64}", image["digest"]):
            raise RuntimeError(f"Invalid image lock: {image['ref']}")
    references = {image["ref"] for image in data["images"]}
    if not set(data["kubeadm_images"]) <= references or data["smoke_image"] not in references or data["pause_image"] not in references:
        raise RuntimeError("Image lock is missing kubeadm/smoke/pause references")
    print("Artifact checksums, lock, version configuration, and required files verified.")


def check_installed(root):
    failures = []
    with (root / "manifest.tsv").open() as stream:
        rows = list(csv.DictReader(stream, delimiter="\t"))
    for row in rows:
        check = subprocess.run(["dpkg-query", "-W", "-f=${db:Status-Status}\t${Version}", row["package"]],
                               text=True, capture_output=True)
        if check.returncode == 0 and check.stdout.startswith("installed\t"):
            current = check.stdout.split("\t", 1)[1]
            if subprocess.run(["dpkg", "--compare-versions", current, "gt", row["version"]]).returncode == 0:
                failures.append(f"{row['package']}: installed {current} > bundle {row['version']}")
    if failures:
        raise RuntimeError("Refusing OS package downgrades. Prepare from a matching/newer Ubuntu snapshot:\n" + "\n".join(failures))


def main():
    action, directory, *args = sys.argv[1:]
    root = Path(directory).resolve()
    if action == "debs":
        debs(root, args[0])
    else:
        {"downloads": downloads, "wheels": wheels, "lock": lock, "sums": sums,
         "verify": verify, "check-installed": check_installed}[action](root)


if __name__ == "__main__":
    try:
        main()
    except (RuntimeError, ValueError, KeyError, subprocess.CalledProcessError) as exc:
        sys.exit(f"ERROR: {exc}")
