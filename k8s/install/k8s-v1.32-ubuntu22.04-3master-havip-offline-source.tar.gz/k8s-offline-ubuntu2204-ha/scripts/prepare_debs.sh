#!/usr/bin/env bash
# ONLINE only, invoked by prepare.sh on a disposable Ubuntu 22.04 amd64 VM.
set -Eeuo pipefail
source "$(dirname -- "${BASH_SOURCE[0]}")/common.sh"
require_ubuntu
load_versions
load_download_sources
mkdir -p "$ARTIFACTS/debs/apt-metadata"
[[ -z "$(find "$ARTIFACTS/debs" -maxdepth 1 -name '*.deb' -print -quit)" ]] || die 'Debian package output is not empty; use a fresh project copy.'
apt_work="$(mktemp -d)"
trap 'rm -rf -- "$apt_work"' EXIT
mkdir -p "$apt_work/lists/partial" "$apt_work/archives/partial"
: > "$apt_work/status"
mkdir -p "$apt_work/empty-config"
write_ubuntu_sources "$apt_work/sources.list"
apt_options=(
  "${apt_proxy_args[@]}"
  -o "Dir::Etc::sourcelist=$apt_work/sources.list" -o "Dir::Etc::sourceparts=$apt_work/empty-config"
  -o Dir::Etc::preferences=/dev/null -o "Dir::Etc::preferencesparts=$apt_work/empty-config"
  -o "Dir::State::lists=$apt_work/lists" -o "Dir::State::status=$apt_work/status"
  -o "Dir::Cache::archives=$apt_work/archives" -o APT::Architecture=amd64
  -o APT::Architectures::=amd64 -o APT::Sandbox::User=root
  -o Acquire::ForceIPv4=true -o Acquire::Retries=2
  -o Acquire::https::Timeout=20 -o APT::Update::Error-Mode=any
  -o Acquire::AllowInsecureRepositories=false -o APT::Get::AllowUnauthenticated=false
)
apt-get "${apt_options[@]}" update
required_packages=(
  python3 python3-venv python3-pip python3-apt conntrack socat iproute2 iptables
  ethtool ebtables util-linux kmod ca-certificates bash coreutils tar gzip mount
  systemd systemd-sysv openssh-client libseccomp2 openssl "haproxy${HAPROXY_DEB_VERSION:+=$HAPROXY_DEB_VERSION}" "keepalived${KEEPALIVED_DEB_VERSION:+=$KEEPALIVED_DEB_VERSION}" procps
)
# Empty dpkg status forces the solver to fetch the WHOLE dependency closure,
# including dependencies already installed on the preparation machine.
apt-get "${apt_options[@]}" -y --download-only --no-install-recommends install "${required_packages[@]}"
cp "$apt_work/archives/"*.deb "$ARTIFACTS/debs/"
cp "$apt_work/sources.list" "$ARTIFACTS/debs/apt-metadata/sources.list"
find "$apt_work/lists" -maxdepth 1 -type f -name '*InRelease' -exec cp '{}' "$ARTIFACTS/debs/apt-metadata/" \;
python3 "$PROJECT_ROOT/scripts/manifest.py" debs "$ARTIFACTS/debs" "$apt_work"
printf '%s\n' "${required_packages[@]}" > "$ARTIFACTS/debs/requested-packages.txt"
