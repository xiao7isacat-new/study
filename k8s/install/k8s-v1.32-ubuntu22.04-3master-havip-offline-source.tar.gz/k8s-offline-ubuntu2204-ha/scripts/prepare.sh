#!/usr/bin/env bash
# ONLINE preparation. Do not run on the future offline Kubernetes node.
set -Eeuo pipefail
source "$(dirname -- "${BASH_SOURCE[0]}")/common.sh"
require_ubuntu
load_versions
load_download_sources
[[ "$PROJECT_ROOT" != *[[:space:]]* ]] || die 'Use a project path without whitespace on the preparation VM.'
existing="$(find "$ARTIFACTS" -type f ! -name README.md ! -name .gitkeep -print -quit)"
[[ -z "$existing" ]] || die "Artifacts already exist ($existing). Preserve that bundle and prepare a new project copy; partial preparation is not silently reused."
mkdir -p "$ARTIFACTS"/{bin,downloads,manifests,images,debs,wheels}
prep_work="$(mktemp -d)"
trap 'rm -rf -- "$prep_work"' EXIT
mkdir -p "$prep_work/empty-config" "$prep_work/lists/partial"
write_ubuntu_sources "$prep_work/sources.list"
# Preparation uses only the configured signed Ubuntu mirror, with fresh isolated indexes.
prep_apt=("${apt_proxy_args[@]}" -o "Dir::State::lists=$prep_work/lists" -o APT::Sandbox::User=root -o "Dir::Etc::sourcelist=$prep_work/sources.list" -o "Dir::Etc::sourceparts=$prep_work/empty-config"
  -o Dir::Etc::preferences=/dev/null -o "Dir::Etc::preferencesparts=$prep_work/empty-config"
  -o Acquire::ForceIPv4=true -o Acquire::Retries=2
  -o Acquire::https::Timeout=20 -o APT::Update::Error-Mode=any
  -o Acquire::AllowInsecureRepositories=false -o APT::Get::AllowUnauthenticated=false)
apt-get "${prep_apt[@]}" update
prepare_tools=(ca-certificates curl skopeo python3 python3-venv python3-pip python3-yaml)
prepare_venv_args=()
if [[ "${K8S_PREPARE_PROXY:-}" == socks5h://* ]]; then
  # Bootstrap pip's SOCKS support using authenticated Ubuntu APT, not pip itself.
  prepare_tools+=(python3-socks)
  prepare_venv_args+=(--system-site-packages)
fi
DEBIAN_FRONTEND=noninteractive apt-get "${prep_apt[@]}" -y --no-install-recommends install "${prepare_tools[@]}"
bash "$PROJECT_ROOT/scripts/prepare_debs.sh"
python3 -m venv "${prepare_venv_args[@]}" "$prep_work/venv"
if [[ "${K8S_PREPARE_PROXY:-}" == socks5h://* ]]; then
  "$prep_work/venv/bin/python" -c 'import socks; print("Temporary preparation pip SOCKS support is available.")'
fi
PIP_CONFIG_FILE=/dev/null "$prep_work/venv/bin/python" -m pip --isolated --disable-pip-version-check download \
  "${pip_proxy_args[@]}" \
  --index-url "$OFFLINE_PYPI_INDEX" --retries 2 --timeout 30 --only-binary=:all: \
  --dest "$ARTIFACTS/wheels" "ansible-core==$ANSIBLE_CORE_VERSION" "tomli==2.2.1"
python3 "$PROJECT_ROOT/scripts/manifest.py" wheels "$ARTIFACTS/wheels"
python3 "$PROJECT_ROOT/scripts/manifest.py" downloads "$ARTIFACTS"
chmod 0755 "$ARTIFACTS/bin/"{kubeadm,kubelet,kubectl}
# Execute the real official binaries on the matching preparation OS before packaging.
"$ARTIFACTS/bin/kubelet" --version
"$ARTIFACTS/bin/kubectl" version --client=true
"$ARTIFACTS/bin/kubeadm" config images list \
  --kubernetes-version "$KUBERNETES_VERSION" --image-repository "$IMAGE_REPOSITORY" \
  > "$ARTIFACTS/manifests/kubeadm-images.txt"
python3 "$PROJECT_ROOT/scripts/prepare_images.py" "$ARTIFACTS"
python3 "$PROJECT_ROOT/scripts/manifest.py" lock "$ARTIFACTS"
python3 "$PROJECT_ROOT/scripts/manifest.py" sums "$ARTIFACTS"
verify_artifacts
printf '\nComplete offline bundle prepared at %s\n' "$PROJECT_ROOT"
printf 'Review artifacts/lock.yml and all manifest.tsv files, then run bash scripts/package.sh\n'
