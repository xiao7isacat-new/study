#!/usr/bin/env python3
"""Destructive rollback of THIS project's fresh three-control-plane install. Run via rollback.yml."""
import argparse
import datetime
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

STATE = Path('/var/lib/k8s-offline')
ALLOWED = {
    '/etc/fstab', '/etc/containerd', '/etc/cni/net.d', '/opt/cni/bin',
    '/etc/crictl.yaml', '/etc/kubernetes', '/var/lib/kubelet', '/var/lib/etcd',
    '/var/lib/containerd', '/var/lib/cni', '/run/flannel',
    '/usr/local/bin/containerd', '/usr/local/bin/containerd-shim',
    '/usr/local/bin/containerd-shim-runc-v1', '/usr/local/bin/containerd-shim-runc-v2',
    '/usr/local/bin/containerd-stress', '/usr/local/bin/ctr', '/usr/local/sbin/runc',
    '/usr/local/bin/crictl', '/usr/local/bin/kubelet', '/usr/local/bin/kubeadm',
    '/usr/local/bin/kubectl', '/etc/systemd/system/containerd.service',
    '/etc/systemd/system/kubelet.service', '/etc/modules-load.d/k8s-offline.conf',
    '/etc/sysctl.d/99-k8s-offline.conf', '/etc/haproxy/haproxy.cfg', '/etc/keepalived/keepalived.conf',
}


def run(argv, required=True, timeout=300):
    result = subprocess.run(argv, text=True, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, timeout=timeout)
    if result.stdout.strip():
        print(result.stdout.strip())
    if required and result.returncode:
        raise RuntimeError(f"Command failed ({result.returncode}): {' '.join(argv)}")
    return result


def erase(path):
    if path.is_symlink() or path.is_file():
        path.unlink()
    elif path.is_dir():
        shutil.rmtree(path)
    elif os.path.lexists(path):
        raise RuntimeError(f"Unsupported path type: {path}")


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--yes-destroy-cluster', action='store_true')
    p.add_argument('--full-ha-teardown', action='store_true')
    args = p.parse_args()
    if not args.full_ha_teardown:
        p.error('HA rollback must be invoked for all three nodes via rollback.yml')
    if not args.yes_destroy_cluster:
        p.error('--yes-destroy-cluster is required; etcd and all cluster state will be removed')
    if os.geteuid() != 0:
        p.error('run as root')
    manifest = STATE / 'backup/manifest.json'
    if (STATE / 'rollback-complete.json').exists():
        raise RuntimeError('Rollback was already completed; review the retained report and backup')
    if not manifest.is_file() or not (STATE / 'cluster-fingerprint.sha256').is_file():
        raise RuntimeError('No project ownership marker/backup; refusing to change this host')
    identity = json.loads((STATE / 'cluster-identity.json').read_text())
    if identity.get('topology') != 'three-control-plane-ha':
        raise RuntimeError('No HA project ownership identity; refusing to reset')
    data = json.loads(manifest.read_text())
    if data.get('schema_version') != 1:
        raise RuntimeError('Unsupported backup manifest')
    paths = data['paths']
    for item in paths:
        if item['path'] not in ALLOWED:
            raise RuntimeError(f"Unexpected managed path: {item['path']}")
        if item['existed']:
            expected = STATE / 'backup/files' / item['path'].lstrip('/')
            if str(expected) != item['backup'] or not os.path.lexists(expected):
                raise RuntimeError(f"Missing or invalid original backup: {item['path']}")
    run(['systemctl', 'stop', 'keepalived', 'haproxy'], required=False)
    run(['systemctl', 'disable', 'keepalived', 'haproxy'], required=False)
    run(['systemctl', 'stop', 'kubelet'], required=False)
    k8s = Path('/etc/kubernetes')
    has_cluster_state = k8s.is_dir() and any(k8s.iterdir())
    if has_cluster_state:
        if not Path('/usr/local/bin/kubeadm').is_file():
            raise RuntimeError('Cluster state exists but kubeadm is missing; repair the binary before reset')
        run(['systemctl', 'start', 'containerd'])
        run(['/usr/local/bin/kubeadm', 'reset', '--force', '--skip-phases=remove-etcd-member',
             '--cri-socket=unix:///run/containerd/containerd.sock'], timeout=600)
    run(['systemctl', 'stop', 'containerd'], required=False)
    run(['systemctl', 'disable', 'kubelet', 'containerd'], required=False)
    # Refuse to recursively remove live mounts left by an incomplete reset.
    directories = [i['path'] for i in paths if i['path'].startswith(('/var/lib/', '/opt/', '/run/flannel'))]
    remaining = []
    for row in Path('/proc/self/mountinfo').read_text().splitlines():
        mount = row.split()[4].replace('\\040', ' ')
        if any(mount == name or mount.startswith(name + '/') for name in directories):
            remaining.append(mount)
    if remaining:
        raise RuntimeError('Live mounts remain; inspect/unmount them before rerunning: ' + ', '.join(remaining))
    for iface in ('flannel.1', 'cni0'):
        if Path('/sys/class/net', iface).exists():
            run(['ip', 'link', 'delete', 'dev', iface])
    for item in paths:
        target = Path(item['path'])
        erase(target)
        if item['existed']:
            source = Path(item['backup'])
            target.parent.mkdir(parents=True, exist_ok=True)
            if item['kind'] == 'symlink':
                target.symlink_to(os.readlink(source))
            elif item['kind'] == 'dir':
                shutil.copytree(source, target, symlinks=True)
            else:
                shutil.copy2(source, target)
    run(['systemctl', 'daemon-reload'])
    problems = []
    for key, value in data.get('sysctls', {}).items():
        if value is not None:
            result = run(['sysctl', '-w', f'{key}={value}'], required=False)
            if result.returncode:
                problems.append('restore sysctl ' + key)
    for service, status in data.get('services', {}).items():
        for action, enabled in [('enable', status['enabled']), ('start', status['active'])]:
            if enabled and run(['systemctl', action, service], required=False).returncode:
                problems.append(f'{action} {service}')
    for swap in data.get('original_swaps', []):
        command = ['swapon']
        if int(swap['priority']) >= 0:
            command += ['--priority', str(swap['priority'])]
        result = run(command + [swap['path']], required=False)
        if result.returncode:
            # A retry may find a swap that is already enabled.
            active = [r.split()[0] for r in Path('/proc/swaps').read_text().splitlines()[1:]]
            if swap['path'] not in active:
                problems.append('restore swap ' + swap['path'])
    report = {
        'completed_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'problems': problems,
        'retained': ['backup', 'artifacts', 'cluster-identity.json'],
        'manual_follow_up': ['reboot to clear nonpersistent kube-proxy/Flannel firewall state',
                             'kernel modules remain loaded until reboot',
                             'offline deb packages and Ansible venv remain installed',
                             'application data outside managed paths is not restored'],
    }
    if problems:
        (STATE / 'rollback-needs-attention.json').write_text(json.dumps(report, indent=2) + '\n')
        raise RuntimeError('Partial restoration; inspect rollback-needs-attention.json: ' + ', '.join(problems))
    (STATE / 'rollback-complete.json').write_text(json.dumps(report, indent=2) + '\n')
    (STATE / 'cluster-fingerprint.sha256').rename(STATE / 'cluster-fingerprint.removed.sha256')
    print(json.dumps(report, indent=2))
    print('Rollback completed. Review the report, then reboot before installing a new cluster.')
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (OSError, ValueError, KeyError, RuntimeError, subprocess.TimeoutExpired) as exc:
        print(f'Rollback stopped: {exc}', file=sys.stderr)
        sys.exit(1)
