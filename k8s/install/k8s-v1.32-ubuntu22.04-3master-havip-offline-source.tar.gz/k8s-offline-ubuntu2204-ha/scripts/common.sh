#!/usr/bin/env bash
# Shared helpers. Source only from this project's scripts.
set -Eeuo pipefail
PROJECT_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
ARTIFACTS="$PROJECT_ROOT/artifacts"
die() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
require_ubuntu() {
  [[ -r /etc/os-release ]] || die 'Missing /etc/os-release'
  # shellcheck disable=SC1091
  . /etc/os-release
  [[ "$ID" == ubuntu && "$VERSION_ID" == 22.04 && "$(dpkg --print-architecture)" == amd64 ]] || die 'Only Ubuntu 22.04 amd64 is supported.'
  [[ "$EUID" == 0 ]] || die 'Run with sudo/root.'
  python3 -c 'import sys; assert sys.version_info[:2] == (3, 10), "Ubuntu stock Python 3.10 is required"'
}
load_versions() {
  [[ -f "$PROJECT_ROOT/config/versions.env" ]] || die 'Missing config/versions.env'
  set -a
  # shellcheck disable=SC1091
  . "$PROJECT_ROOT/config/versions.env"
  set +a
  local var
  for var in KUBERNETES_VERSION CONTAINERD_VERSION RUNC_VERSION CNI_PLUGINS_VERSION CRICTL_VERSION FLANNEL_VERSION ANSIBLE_CORE_VERSION IMAGE_REPOSITORY SMOKE_IMAGE; do
    [[ -n "${!var:-}" ]] || die "Missing $var in config/versions.env"
  done
  [[ "$KUBERNETES_VERSION" =~ ^v1\.32\.[0-9]+$ ]] || die 'This project supports Kubernetes v1.32.x only; other minors require review.'
  [[ "$CONTAINERD_VERSION" =~ ^1\.7\.[0-9]+$ ]] || die 'The containerd schema-2 template supports 1.7.x only.'
  [[ "$CRICTL_VERSION" =~ ^v1\.32\.[0-9]+$ ]] || die 'Use crictl v1.32.x with Kubernetes v1.32.x.'
  python3 -c 'import sys; assert tuple(map(int,sys.argv[1].split("."))) >= (1,7,24), "containerd 1.7.24+ is required for the Kubernetes 1.32 compatibility baseline"' "$CONTAINERD_VERSION"
}
verify_artifacts() {
  [[ -s "$ARTIFACTS/SHA256SUMS" && -s "$ARTIFACTS/lock.yml" ]] || die 'Run online preparation first; complete artifacts are required.'
  (cd "$ARTIFACTS" && sha256sum --check --strict SHA256SUMS)
  python3 "$PROJECT_ROOT/scripts/manifest.py" verify "$ARTIFACTS"
}
load_download_sources() {
  [[ -f "$PROJECT_ROOT/config/downloads.env" ]] || die 'Missing config/downloads.env'
  set -a
  # shellcheck disable=SC1091
  . "$PROJECT_ROOT/config/downloads.env"
  set +a
  python3 "$PROJECT_ROOT/scripts/download_sources.py"
  apt_proxy_args=()
  pip_proxy_args=()
  if [[ -n "${K8S_PREPARE_PROXY:-}" ]]; then
    apt_proxy_args=(-o "Acquire::http::Proxy=$K8S_PREPARE_PROXY" -o "Acquire::https::Proxy=$K8S_PREPARE_PROXY")
    pip_proxy_args=(--proxy "$K8S_PREPARE_PROXY")
    # This affects only the preparation process and its children.
    export no_proxy='' NO_PROXY=''
    printf 'Preparation proxy enabled for APT, pip, curl and skopeo.\n'
  fi
}
write_ubuntu_sources() {
  cat > "$1" <<EOF
deb [arch=amd64 signed-by=/usr/share/keyrings/ubuntu-archive-keyring.gpg] $OFFLINE_APT_MIRROR jammy main universe
deb [arch=amd64 signed-by=/usr/share/keyrings/ubuntu-archive-keyring.gpg] $OFFLINE_APT_MIRROR jammy-updates main universe
deb [arch=amd64 signed-by=/usr/share/keyrings/ubuntu-archive-keyring.gpg] $OFFLINE_APT_SECURITY_MIRROR jammy-security main universe
EOF
}
