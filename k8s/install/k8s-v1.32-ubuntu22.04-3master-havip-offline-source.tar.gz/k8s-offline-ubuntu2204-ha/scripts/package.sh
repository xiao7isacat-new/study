#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname -- "${BASH_SOURCE[0]}")/common.sh"
verify_artifacts
archive="${1:-$PROJECT_ROOT/../k8s-offline-ubuntu22-ha-amd64.tar.gz}"
[[ "$archive" = /* ]] || archive="$PWD/$archive"
[[ ! -e "$archive" ]] || die "Output exists: $archive"
case "$archive" in "$PROJECT_ROOT"/*) die 'Write the archive outside the project directory.' ;; esac
# An allowlist avoids accidentally shipping kubeconfig, secrets, or a live venv.
tar -czf "$archive" -C "$(dirname "$PROJECT_ROOT")" \
  --exclude='*/__pycache__' --exclude='*.pyc' \
  "$(basename "$PROJECT_ROOT")/README.md" \
  "$(basename "$PROJECT_ROOT")/ansible.cfg" \
  "$(basename "$PROJECT_ROOT")/inventory.example.ini" \
  "$(basename "$PROJECT_ROOT")/config" \
  "$(basename "$PROJECT_ROOT")/playbooks" \
  "$(basename "$PROJECT_ROOT")/scripts" \
  "$(basename "$PROJECT_ROOT")/docs" \
  "$(basename "$PROJECT_ROOT")/tests" \
  "$(basename "$PROJECT_ROOT")/artifacts"
(cd "$(dirname "$archive")" && sha256sum "$(basename "$archive")") > "$archive.sha256"
printf 'Created %s\nChecksum: %s.sha256\n' "$archive" "$archive"
