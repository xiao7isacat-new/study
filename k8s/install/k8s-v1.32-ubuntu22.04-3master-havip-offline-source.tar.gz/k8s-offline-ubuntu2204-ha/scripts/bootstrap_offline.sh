#!/usr/bin/env bash
# OFFLINE bootstrap on each target AND each Ubuntu 22.04 amd64 controller.
set -Eeuo pipefail
source "$(dirname -- "${BASH_SOURCE[0]}")/common.sh"
require_ubuntu
verify_artifacts
# Refuse essential-library downgrades. A fresh target must match the prepared
# Ubuntu release/snapshot (or be older); do not force an unsafe downgrade.
python3 "$PROJECT_ROOT/scripts/manifest.py" check-installed "$ARTIFACTS/debs"
mapfile -t deb_files < <(python3 -c 'from pathlib import Path; import sys; print("\n".join(str(p) for p in sorted(Path(sys.argv[1]).glob("*.deb"))))' "$ARTIFACTS/debs")
[[ "${#deb_files[@]}" -gt 0 ]] || die 'No offline Debian packages found.'
offline_apt_work="$(mktemp -d)"
trap 'rm -rf -- "$offline_apt_work"' EXIT
mkdir -p "$offline_apt_work/empty-config"
# No source entries, no index refresh, no downloads, no online repair fallback.
DEBIAN_FRONTEND=noninteractive apt-get \
  -o Dir::Etc::sourcelist=/dev/null -o "Dir::Etc::sourceparts=$offline_apt_work/empty-config" \
  -o Dir::Etc::preferences=/dev/null -o "Dir::Etc::preferencesparts=$offline_apt_work/empty-config" \
  -o Acquire::Retries=0 -o APT::Get::Download=false \
  -y --no-download --no-remove --no-install-recommends install "${deb_files[@]}"
if [[ ! -x "$PROJECT_ROOT/.venv/bin/python" ]]; then
  python3 -m venv "$PROJECT_ROOT/.venv"
fi
PIP_CONFIG_FILE=/dev/null "$PROJECT_ROOT/.venv/bin/python" -m pip --isolated --disable-pip-version-check install \
  --no-index --only-binary=:all: --find-links "$ARTIFACTS/wheels" \
  --require-hashes -r "$ARTIFACTS/wheels/requirements.lock"
"$PROJECT_ROOT/.venv/bin/ansible-playbook" --version
printf '\nOffline bootstrap complete. Ansible: %s/.venv/bin/ansible-playbook\n' "$PROJECT_ROOT"
