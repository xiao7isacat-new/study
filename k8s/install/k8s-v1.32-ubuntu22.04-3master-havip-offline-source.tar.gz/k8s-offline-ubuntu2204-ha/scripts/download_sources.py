#!/usr/bin/env python3
"""Preparation transport policy; no network access at import or on offline nodes."""
from html.parser import HTMLParser
import os
import re
from urllib.parse import parse_qs, unquote, urldefrag, urljoin, urlsplit


DEFAULTS = {
    'OFFLINE_APT_MIRROR': 'https://mirrors.aliyun.com/ubuntu',
    'OFFLINE_APT_SECURITY_MIRROR': 'https://mirrors.aliyun.com/ubuntu',
    'OFFLINE_PYPI_INDEX': 'https://mirrors.aliyun.com/pypi/simple',
    'OFFLINE_BINARY_MIRROR': 'https://files.m.daocloud.io',
    'OFFLINE_IMAGE_MIRROR': 'm.daocloud.io',
}


def prepare_proxy():
    """Runtime-only preparation setting; never included in bundle metadata."""
    value = os.environ.get('K8S_PREPARE_PROXY', '')
    if not value:
        return ''
    parsed = urlsplit(value)
    if (parsed.scheme not in {'socks5h', 'http', 'https'} or not parsed.hostname or
            not parsed.port or parsed.username or parsed.password or parsed.query or
            parsed.fragment or parsed.path not in {'', '/'} or any(c.isspace() for c in value)):
        raise ValueError('K8S_PREPARE_PROXY requires socks5h/http/https://host:port without credentials or a path')
    return parsed.geturl().rstrip('/')


def curl_proxy_args():
    proxy = prepare_proxy()
    return ['--proxy', proxy, '--noproxy', ''] if proxy else []


def skopeo_environment():
    environment = os.environ.copy()
    proxy = prepare_proxy()
    if proxy:
        # Ubuntu 22.04's Go transport accepts socks5, with remote destination DNS,
        # but old Go releases do not recognize the socks5h scheme used by curl/pip/APT.
        go_proxy = proxy.replace('socks5h://', 'socks5://', 1)
        for key in ('http_proxy', 'https_proxy', 'HTTP_PROXY', 'HTTPS_PROXY', 'all_proxy', 'ALL_PROXY'):
            environment[key] = go_proxy
        environment['no_proxy'] = environment['NO_PROXY'] = ''
    return environment


def https_base(value):
    parsed = urlsplit(value)
    if (parsed.scheme != 'https' or not parsed.hostname or parsed.username or
            parsed.password or parsed.query or parsed.fragment or any(c.isspace() for c in value)):
        raise ValueError('Download base must be an HTTPS URL without credentials, query or fragment')
    return value.rstrip('/')


def settings():
    result = {key: os.environ.get(key, default).rstrip('/') for key, default in DEFAULTS.items()}
    for key in DEFAULTS:
        if key != 'OFFLINE_IMAGE_MIRROR':
            https_base(result[key])
    image_mirror = result['OFFLINE_IMAGE_MIRROR']
    if not image_mirror or not re.fullmatch(r'[A-Za-z0-9.:-]+(?:/[A-Za-z0-9_.-]+)*', image_mirror):
        raise ValueError('Image mirror must be registry[:port][/prefix], without a URL scheme')
    return result


def file_url(original):
    parsed = urlsplit(original)
    if parsed.scheme != 'https' or parsed.netloc not in ('github.com', 'dl.k8s.io'):
        raise ValueError('Unsupported original binary URL')
    return settings()['OFFLINE_BINARY_MIRROR'] + '/' + parsed.netloc + parsed.path


def image_ref(original):
    # This project uses fully qualified, tagged image names from kubeadm/Flannel.
    registry, separator, _ = original.partition('/')
    if not separator or not ('.' in registry or ':' in registry or registry == 'localhost'):
        raise ValueError('Image must have an explicit original registry: ' + original)
    return settings()['OFFLINE_IMAGE_MIRROR'] + '/' + original


def apt_url_allowed(url):
    return any(url.startswith(base.rstrip('/') + '/') for base in (
        settings()['OFFLINE_APT_MIRROR'], settings()['OFFLINE_APT_SECURITY_MIRROR']))


class WheelLinks(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links = []

    def handle_starttag(self, tag, attrs):
        if tag.lower() == 'a':
            self.links.extend(value for key, value in attrs if key.lower() == 'href' and value)


def wheel_index_url(name):
    normalized = re.sub(r'[-_.]+', '-', name).lower()
    return settings()['OFFLINE_PYPI_INDEX'] + '/' + normalized + '/'


def wheel_record(html, index_url, filename, digest):
    parser = WheelLinks()
    parser.feed(html)
    found = set()
    for href in parser.links:
        complete = urljoin(index_url, href)
        url, fragment = urldefrag(complete)
        if unquote(urlsplit(url).path.rsplit('/', 1)[-1]) != filename:
            continue
        hashes = parse_qs(fragment).get('sha256', [])
        if len(hashes) != 1 or hashes[0] != digest or not re.fullmatch(r'[0-9a-f]{64}', digest):
            raise RuntimeError('Mirror simple-index SHA256 mismatch for ' + filename)
        parsed = urlsplit(url)
        if parsed.scheme != 'https' or parsed.username or parsed.password:
            raise RuntimeError('Wheel URL must use HTTPS without credentials')
        # TUNA may use either its independent PyPI hostname or its shared hostname.
        configured = urlsplit(index_url).hostname
        hosts = {configured}
        if configured in {'pypi.tuna.tsinghua.edu.cn', 'mirrors.tuna.tsinghua.edu.cn'}:
            hosts.update({'pypi.tuna.tsinghua.edu.cn', 'mirrors.tuna.tsinghua.edu.cn'})
        if parsed.hostname not in hosts:
            raise RuntimeError('Wheel index points outside the configured mirror: ' + url)
        found.add(url)
    if len(found) != 1:
        raise RuntimeError('Expected one mirrored wheel URL/hash for ' + filename)
    return found.pop()


if __name__ == '__main__':
    import json
    prepare_proxy()  # Validate without logging or persisting the proxy address.
    print(json.dumps(settings(), indent=2))
