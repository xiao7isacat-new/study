#!/usr/bin/env python3
"""ONLINE: derive image inventory and archive immutable linux/amd64 leaves."""
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile

import yaml  # Ubuntu python3-yaml, installed only by online prepare.sh
import download_sources

from manifest import sha, table


def command(args):
    return subprocess.check_output(args, env=download_sources.skopeo_environment())


def repository(ref):
    if "@" in ref:
        return ref.split("@", 1)[0]
    slash = ref.rfind("/")
    colon = ref.rfind(":")
    return ref[:colon] if colon > slash else ref


def walk_images(value):
    if isinstance(value, dict):
        for key, child in value.items():
            if key == "image" and isinstance(child, str):
                yield child
            else:
                yield from walk_images(child)
    elif isinstance(value, list):
        for child in value:
            yield from walk_images(child)


def image_leaf(ref):
    raw = command(["skopeo", "inspect", "--raw", "docker://" + ref])
    document = json.loads(raw)
    repo = repository(ref)
    if "manifests" in document:
        candidates = [item for item in document["manifests"] if item.get("platform", {}).get("architecture") == "amd64"
                      and item.get("platform", {}).get("os") == "linux"
                      and item.get("platform", {}).get("variant", "") in ("", "v1")]
        if len(candidates) != 1:
            raise RuntimeError(f"Expected exactly one linux/amd64 manifest: {ref}")
        digest = candidates[0]["digest"]
    else:
        # skopeo's manifest-digest applies the registry manifest digest rules.
        with tempfile.NamedTemporaryFile() as stream:
            stream.write(raw)
            stream.flush()
            digest = command(["skopeo", "manifest-digest", stream.name]).decode().strip()
    if not re.fullmatch(r"sha256:[0-9a-f]{64}", digest):
        raise RuntimeError(f"Unsupported image digest {digest}")
    source = repo + "@" + digest
    configuration = json.loads(command(["skopeo", "inspect", "--config", "docker://" + source]))
    if (configuration.get("os"), configuration.get("architecture")) != ("linux", "amd64"):
        raise RuntimeError(f"Selected leaf is not linux/amd64: {ref}")
    return digest, source


def main(root):
    kubeadm = (root / "manifests/kubeadm-images.txt").read_text().splitlines()
    flannel = []
    with (root / "manifests/kube-flannel.yml").open() as stream:
        for document in yaml.safe_load_all(stream):
            flannel.extend(walk_images(document))
    flannel = list(dict.fromkeys(flannel))
    if len(flannel) < 2:
        raise RuntimeError("Pinned Flannel manifest did not contain daemon and CNI images")
    references = list(dict.fromkeys(kubeadm + flannel + [os.environ["SMOKE_IMAGE"]]))
    rows = []
    for ref in references:
        if not ref or "@" in ref or ref.endswith(":latest") or ":" not in ref.rsplit("/", 1)[-1]:
            raise RuntimeError(f"Image input must have an explicit non-latest tag (digest is resolved and locked during preparation): {ref}")
        mirror_ref = download_sources.image_ref(ref)
        digest, source = image_leaf(mirror_ref)
        slug = re.sub(r"[^A-Za-z0-9_.-]", "_", ref)
        archive = f"images/{slug}.tar"
        if (root / archive).exists():
            raise RuntimeError(f"Refusing to overwrite image archive {archive}")
        subprocess.run(["skopeo", "--override-os", "linux", "--override-arch", "amd64", "copy",
                        "docker://" + source, f"docker-archive:{root / archive}:{ref}"], check=True,
                       env=download_sources.skopeo_environment())
        # Inspect the archive itself to verify its original name and architecture.
        archive_info = json.loads(command(["skopeo", "inspect", f"docker-archive:{root / archive}:{ref}"]))
        if (archive_info.get("Os"), archive_info.get("Architecture")) != ("linux", "amd64"):
            raise RuntimeError(f"Wrong archive platform: {archive}")
        rows.append(dict(ref=ref, archive=archive, digest=digest, source=source, mirror_ref=mirror_ref,
                         digest_verification="resolved from configured mirror; original registry not contacted",
                         archive_sha256=sha(root / archive), os="linux", arch="amd64"))
    (root / "images/manifest.json").write_text(json.dumps(rows, indent=2) + "\n")
    table(root / "images/manifest.tsv", ["ref", "archive", "digest", "source", "mirror_ref", "digest_verification", "archive_sha256", "os", "arch"], rows)
    (root / "manifests/flannel-images.txt").write_text("\n".join(flannel) + "\n")


if __name__ == "__main__":
    main(Path(sys.argv[1]).resolve())
