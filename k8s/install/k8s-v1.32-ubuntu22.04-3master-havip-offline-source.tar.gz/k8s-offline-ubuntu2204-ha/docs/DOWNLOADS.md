# 三主工程的下载补充

本版新增 Ubuntu 官方仓库的 haproxy、keepalived、procps 及全部传递依赖；精确文件放在 artifacts/debs/，实际版本/完整镜像 URL/架构/SHA256 在 artifacts/debs/manifest.tsv。签名仍由 Ubuntu archive keyring 验证。HAPROXY_DEB_VERSION、KEEPALIVED_DEB_VERSION 可在 config/versions.env 中预先指定完整 Debian revision；默认空值按准备时签名候选解析。lock.yml 记录实际 load_balancer_versions，节点预检查要求完全匹配。

这些服务采用原生 Deb 和 systemd，所以没有新增 HAProxy/Keepalived 容器镜像。Kubernetes/Flannel/验收镜像仍是下面列出的十张，每台分别导入同一套精确引用。本工程要求三主 topology 字段，不能直接复用旧单节点 lock。

- [Ubuntu jammy HAProxy 包](https://packages.ubuntu.com/jammy/haproxy)
- [Ubuntu jammy Keepalived 包](https://packages.ubuntu.com/jammy/keepalived)
- 国内签名仓库入口：[https://mirrors.aliyun.com/ubuntu/dists/jammy/InRelease](https://mirrors.aliyun.com/ubuntu/dists/jammy/InRelease)
- 更新/安全仓库入口：[https://mirrors.aliyun.com/ubuntu/dists/jammy-updates/InRelease](https://mirrors.aliyun.com/ubuntu/dists/jammy-updates/InRelease) 、[https://mirrors.aliyun.com/ubuntu/dists/jammy-security/InRelease](https://mirrors.aliyun.com/ubuntu/dists/jammy-security/InRelease)

其余版本、上游原始链接、国内传输入口和各文件路径如下。

# 下载清单、官方来源与目录

所有路径都相对于 `k8s-offline-ubuntu2204-ha/`。默认由 `sudo bash scripts/prepare.sh` 下载，无需逐个重命名或手工维护依赖。国内版实际下载地址见 [CHINA_DOWNLOADS.md](CHINA_DOWNLOADS.md)。下表保留默认版本的精确官方来源 URL 供追溯，不代表脚本会直接访问这些国外地址；文件名在工程内统一，实际版本同时写入清单和 lock。

## 二进制和清单

| 项目/版本 | 精确官方 URL | 下载后工程路径 |
|---|---|---|
| kubeadm v1.32.13 | [https://dl.k8s.io/release/v1.32.13/bin/linux/amd64/kubeadm](https://dl.k8s.io/release/v1.32.13/bin/linux/amd64/kubeadm) | `artifacts/bin/kubeadm` |
| kubelet v1.32.13 | [https://dl.k8s.io/release/v1.32.13/bin/linux/amd64/kubelet](https://dl.k8s.io/release/v1.32.13/bin/linux/amd64/kubelet) | `artifacts/bin/kubelet` |
| kubectl v1.32.13 | [https://dl.k8s.io/release/v1.32.13/bin/linux/amd64/kubectl](https://dl.k8s.io/release/v1.32.13/bin/linux/amd64/kubectl) | `artifacts/bin/kubectl` |
| containerd 1.7.36 | [https://github.com/containerd/containerd/releases/download/v1.7.36/containerd-1.7.36-linux-amd64.tar.gz](https://github.com/containerd/containerd/releases/download/v1.7.36/containerd-1.7.36-linux-amd64.tar.gz) | `artifacts/downloads/containerd.tar.gz` |
| runc 1.3.4 | [https://github.com/opencontainers/runc/releases/download/v1.3.4/runc.amd64](https://github.com/opencontainers/runc/releases/download/v1.3.4/runc.amd64) | `artifacts/downloads/runc.amd64` |
| CNI reference plugins 1.7.1 | [https://github.com/containernetworking/plugins/releases/download/v1.7.1/cni-plugins-linux-amd64-v1.7.1.tgz](https://github.com/containernetworking/plugins/releases/download/v1.7.1/cni-plugins-linux-amd64-v1.7.1.tgz) | `artifacts/downloads/cni-plugins.tgz` |
| crictl v1.32.0 | [https://github.com/kubernetes-sigs/cri-tools/releases/download/v1.32.0/crictl-v1.32.0-linux-amd64.tar.gz](https://github.com/kubernetes-sigs/cri-tools/releases/download/v1.32.0/crictl-v1.32.0-linux-amd64.tar.gz) | `artifacts/downloads/crictl.tar.gz` |
| Flannel v0.28.4 发行清单 | [https://github.com/flannel-io/flannel/releases/download/v0.28.4/kube-flannel.yml](https://github.com/flannel-io/flannel/releases/download/v0.28.4/kube-flannel.yml) | `artifacts/manifests/kube-flannel.yml` |

校验文件（下载脚本会真实核对，不只是下载）：

| 上游校验 URL | 工程路径 |
|---|---|
| [https://dl.k8s.io/release/v1.32.13/bin/linux/amd64/kubeadm.sha256](https://dl.k8s.io/release/v1.32.13/bin/linux/amd64/kubeadm.sha256) | `artifacts/downloads/checksums/kubeadm.sha256.txt` |
| [https://dl.k8s.io/release/v1.32.13/bin/linux/amd64/kubelet.sha256](https://dl.k8s.io/release/v1.32.13/bin/linux/amd64/kubelet.sha256) | `artifacts/downloads/checksums/kubelet.sha256.txt` |
| [https://dl.k8s.io/release/v1.32.13/bin/linux/amd64/kubectl.sha256](https://dl.k8s.io/release/v1.32.13/bin/linux/amd64/kubectl.sha256) | `artifacts/downloads/checksums/kubectl.sha256.txt` |
| [https://github.com/containerd/containerd/releases/download/v1.7.36/containerd-1.7.36-linux-amd64.tar.gz.sha256sum](https://github.com/containerd/containerd/releases/download/v1.7.36/containerd-1.7.36-linux-amd64.tar.gz.sha256sum) | `artifacts/downloads/checksums/containerd.tar.gz.sha256.txt` |
| [https://github.com/opencontainers/runc/releases/download/v1.3.4/runc.sha256sum](https://github.com/opencontainers/runc/releases/download/v1.3.4/runc.sha256sum) | `artifacts/downloads/checksums/runc.amd64.sha256.txt` |
| [https://github.com/containernetworking/plugins/releases/download/v1.7.1/cni-plugins-linux-amd64-v1.7.1.tgz.sha256](https://github.com/containernetworking/plugins/releases/download/v1.7.1/cni-plugins-linux-amd64-v1.7.1.tgz.sha256) | `artifacts/downloads/checksums/cni-plugins.tgz.sha256.txt` |
| [https://github.com/kubernetes-sigs/cri-tools/releases/download/v1.32.0/crictl-v1.32.0-linux-amd64.tar.gz.sha256](https://github.com/kubernetes-sigs/cri-tools/releases/download/v1.32.0/crictl-v1.32.0-linux-amd64.tar.gz.sha256) | `artifacts/downloads/checksums/crictl.tar.gz.sha256.txt` |

`artifacts/downloads/manifest.tsv` 记录每项版本、实际镜像 URL、最终重定向 URL、官方来源 URL、实际及官方校验 URL、SHA256 与验证方式。二进制和上游格式 SHA sidecar 都通过配置的国内镜像取得，不能把同一第三方镜像返回的文件与 hash 称为独立官方身份验证；不声称完成了 GPG/cosign detached signature 验证。Flannel 清单没有在本工程使用独立的官方 checksum sidecar，按固定发行 URL 经 HTTPS 下载后记录 SHA（TOFU）；总体 SHA256SUMS 保护后续搬运完整性。需要更强供应链验证时，在联网隔离准备区另行完成签名验证并保管已批准的整包 SHA。

2026-10-20 核验到的 Flannel v0.28.4 release asset 为 4476 字节，SHA256 `d078019743c5e0194ce965125fc80ef00af0c1661ec9e12396311f1cfec860a2`；crictl v1.32.0 amd64 SHA256 为 `f050b71d3a73a91a4e0990b90143ed04dcd100cc66f953736fcb6a2730e283c4`。实际安装以完整包内真实校验结果为准。GitHub **发行附件**和仓库同 tag 的 raw YAML 可能不是逐字相同文件，勿拿其中一个的 hash 校验另一个。

## OS Deb 包：完整依赖闭包，不只列几个顶层包

仅支持 Ubuntu jammy amd64，国内版默认来源如下，可在 config/downloads.env 修改：

```text
https://mirrors.aliyun.com/ubuntu  jammy          main universe
https://mirrors.aliyun.com/ubuntu  jammy-updates  main universe
https://mirrors.aliyun.com/ubuntu jammy-security main universe
```

使用系统 Ubuntu archive keyring 验证仓库签名；禁止未认证 APT 下载。脚本用**空 dpkg status**求解依赖，避免准备机已经安装 Python/libc 后把这些依赖漏掉。

顶层请求包：

```text
python3 python3-venv python3-pip python3-apt
conntrack socat iproute2 iptables ethtool ebtables
util-linux kmod ca-certificates bash coreutils tar gzip mount
systemd systemd-sysv openssh-client libseccomp2 openssl
haproxy keepalived procps
```

还会下载 solver 解析出的 Python 3.10、venv/ensurepip、libc、libssl、libmnl/libnftnl、libxtables、libnetfilter-conntrack、systemd 等全部声明依赖。原始 Ubuntu 安装必须已经有 APT/dpkg、基础 shell、Python3.10 与运行内核及模块；本工程不把内核、SSH 服务或整套 OS 引导系统伪装为 Kubernetes 依赖包。

| 文件 | 放置位置/说明 |
|---|---|
| 所有 `.deb` | `artifacts/debs/<APT 产生的原始文件名>.deb`，不要改名 |
| 每包精确版本、架构、实际镜像下载 URL、SHA256 | **`artifacts/debs/manifest.tsv`**，由认证 APT 元数据及真实下载结果生成 |
| 仓库入口与 InRelease | `artifacts/debs/apt-metadata/` |
| 顶层包请求记录 | `artifacts/debs/requested-packages.txt` |

国内版 APT 包的精确完整 URL 通常是 `https://mirrors.aliyun.com/ubuntu/pool/.../*.deb`，包的真实性由 Ubuntu 仓库签名与包 SHA256 共同校验。由于更新仓库和目标基线会变化，源工程不会捏造一张永久有效的传递依赖版本表。**下载完成的 manifest.tsv 就是该离线包每一项包版本、精确镜像下载链接和落盘文件的可审计清单**；使用同一个完整包，不在离线区重新求解、下载或混入其他版本。后续重新准备可能解析出更新的 OS 依赖，故不是跨时间的 bit-for-bit 可复现下载。

联网准备机另外在线安装 `curl skopeo python3-yaml` 等下载工具；离线目标机不需要 skopeo、curl、Docker 或 PyYAML 系统包，Ansible 的 PyYAML 来自本地 wheels。

## Ansible 和 Python wheels

默认 `ansible-core==2.17.14`；工具链是固定输入，不表示“当前最新”。Ubuntu 22.04 的 Python3.10 可运行该版本。可以在准备前修改版本，随后运行工程检查并重新验收；不要在现有 `.venv` 中在线升级。

- 国内下载索引：[阿里云 PyPI simple](https://mirrors.aliyun.com/pypi/simple/)。
- wheel 来源与 hash 的验证索引：[ansible-core](https://mirrors.aliyun.com/pypi/simple/ansible-core/)，只使用镜像返回的 HTTPS 文件 URL 和 `#sha256=`，保存原始索引 HTML。
- 下载内容：ansible-core、Jinja2、PyYAML、cryptography、packaging、resolvelib 以及适用 wheels 的传递依赖；额外固定下载 `tomli==2.2.1`，用于 Python 3.10 下的 TOML 配置检查：[镜像索引](https://mirrors.aliyun.com/pypi/simple/tomli/)。所有 wheel 都会写入同一份版本与 SHA256 清单。
- 所有文件放 `artifacts/wheels/*.whl`；`pip download --only-binary=:all:` 不允许源代码包/现场编译。
- `artifacts/wheels/manifest.tsv` 逐项记录真实 **精确版本、镜像文件 URL、镜像索引 URL 和 SHA256**；脚本根据阿里云 simple 索引核对文件 SHA，不访问 pypi.org JSON。索引 HTML 保存在 `artifacts/wheels/index-metadata/`。
- `artifacts/wheels/requirements.lock` 给所有下载 wheel 写入版本与 hash，离线 `pip --no-index --require-hashes` 使用它。

传递依赖版本在准备时解析并写入 lock，源工程不预填未经下载核实的 hash。Python 次版本及平台变化必须重新准备，不能复用其他 OS/架构的 wheel 目录。

## 默认镜像清单与具体文件名

以下是 v1.32.13 默认镜像和 Flannel **发行清单**中的镜像；下载脚本会从实际 kubeadm 和清单重新提取并核对，不把本表当作代码常量。额外 BusyBox 用于完全离线验收。

| 原始镜像引用 | 工程内 Docker archive 路径 |
|---|---|
| `registry.k8s.io/kube-apiserver:v1.32.13` | `artifacts/images/registry.k8s.io_kube-apiserver_v1.32.13.tar` |
| `registry.k8s.io/kube-controller-manager:v1.32.13` | `artifacts/images/registry.k8s.io_kube-controller-manager_v1.32.13.tar` |
| `registry.k8s.io/kube-scheduler:v1.32.13` | `artifacts/images/registry.k8s.io_kube-scheduler_v1.32.13.tar` |
| `registry.k8s.io/kube-proxy:v1.32.13` | `artifacts/images/registry.k8s.io_kube-proxy_v1.32.13.tar` |
| `registry.k8s.io/coredns/coredns:v1.11.3` | `artifacts/images/registry.k8s.io_coredns_coredns_v1.11.3.tar` |
| `registry.k8s.io/etcd:3.5.24-0` | `artifacts/images/registry.k8s.io_etcd_3.5.24-0.tar` |
| `registry.k8s.io/pause:3.10` | `artifacts/images/registry.k8s.io_pause_3.10.tar` |
| `ghcr.io/flannel-io/flannel:v0.28.4` | `artifacts/images/ghcr.io_flannel-io_flannel_v0.28.4.tar` |
| `ghcr.io/flannel-io/flannel-cni-plugin:v1.9.1-flannel1` | `artifacts/images/ghcr.io_flannel-io_flannel-cni-plugin_v1.9.1-flannel1.tar` |
| `registry.k8s.io/e2e-test-images/busybox:1.29-4` | `artifacts/images/registry.k8s.io_e2e-test-images_busybox_1.29-4.tar` |

镜像官方入口是 `registry.k8s.io` 和 Flannel 官方组织 `ghcr.io/flannel-io`，使用 OCI/Docker Registry 协议，**不是静态 `.tar` 下载链接**。例如 manifest 入口 `https://registry.k8s.io/v2/kube-apiserver/manifests/v1.32.13`，仓库可能要求认证流程或重定向。不能把 CDN 临时签名 URL 当永久下载 URL。

`registry.k8s.io` 的后端、重定向、标签解析和可用性会变化。国内版通过 `m.daocloud.io/<原仓库>/<原路径>:<tag>` 传输；准备流程先从此镜像解析 tag 对应的 manifest index，再选择唯一的 **linux/amd64 子 manifest**，核对镜像配置架构，以 `仓库@sha256:...` 下载，并在 archive 中保留**原始完整 tag**。实际 digest（从镜像解析，未独立访问官方仓库比对）、archive SHA256、架构、镜像来源和原始引用写入 `artifacts/images/manifest.tsv`/`manifest.json` 与 `lock.yml`。Docker archive 转换 manifest 媒体类型后，导入 digest 可能不同，因此目标端验证 archive SHA 和精确 CRI tag，不能错误地要求导入 digest 等于上游 digest。

`IMAGE_REPOSITORY` 可在准备前设置为提前同步好的内网仓库，但不会替你同步、改标签或规避认证。更改 repository 后 kubeadm 的 CoreDNS 路径也可能变化，必须重新生成清单和全部包；Flannel 的引用则来自其本地发行 YAML，不自动跟随 kubeadm 仓库重写。不能在线区凭猜测改镜像名后只保存一个无效 tar。

## 手动下载/打包命令的等价示例

推荐运行主脚本，它同时生成元数据和全包校验。若审核过程需要查看等价命令：

```bash
# 联网 Ubuntu 准备机，工程根目录；示例只展示关键动作，不代替全套 prepare。
curl -fL --proto '=https' \
  https://files.m.daocloud.io/dl.k8s.io/release/v1.32.13/bin/linux/amd64/kubeadm \
  -o artifacts/bin/kubeadm
curl -fL --proto '=https' \
  https://files.m.daocloud.io/dl.k8s.io/release/v1.32.13/bin/linux/amd64/kubeadm.sha256 \
  -o artifacts/downloads/checksums/kubeadm.sha256.txt
chmod +x artifacts/bin/kubeadm
artifacts/bin/kubeadm config images list \
  --kubernetes-version v1.32.13 --image-repository registry.k8s.io

# prepare_images.py 对每个解析出的 amd64 digest 执行这种复制。
# 用实际 manifest.tsv 的值替换 DIGEST，不能把字面量占位值拿来下载。
skopeo --override-os linux --override-arch amd64 copy \
  docker://m.daocloud.io/registry.k8s.io/kube-apiserver@sha256:DIGEST \
  docker-archive:artifacts/images/registry.k8s.io_kube-apiserver_v1.32.13.tar:registry.k8s.io/kube-apiserver:v1.32.13

# 完整物料生成后，统一校验并打包：
sudo bash scripts/package.sh /opt/k8s-offline-ubuntu22-ha-amd64.tar.gz

# 目标端使用的实际导入方式（playbook 已自动执行）：
sudo /usr/local/bin/ctr --namespace k8s.io images import --platform linux/amd64 \
  /var/lib/k8s-offline/artifacts/images/registry.k8s.io_kube-apiserver_v1.32.13.tar
sudo /usr/local/bin/crictl images
```

不要用默认 containerd namespace 导入，不要直接把多架构索引缺层的 archive 当作完整多架构包，也不要漏掉 Flannel initContainer 的 CNI plugin 镜像。无需单独下载 `flannel` CNI 二进制：由已缓存的官方 flannel-cni-plugin initContainer 安装到 `/opt/cni/bin`；reference CNI archive 则提供 bridge/host-local/loopback/portmap 等基础插件。
