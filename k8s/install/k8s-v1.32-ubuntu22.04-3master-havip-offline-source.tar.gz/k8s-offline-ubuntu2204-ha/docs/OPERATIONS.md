# 三主集群运维、网络和基本恢复

## 网络前提

HaVIP 192.168.0.62 已由用户确认创建并关联三台云主机。本工程使用 Keepalived 单播 VRRP + HAProxy TCP 转发；不调用云厂商 API，也不替代云控制台的资源关联/路由/安全组配置。平台名称未给出，规则必须以实际平台为准。以 [阿里云 HaVIP 文档](https://www.alibabacloud.com/help/en/vpc/highly-available-virtual-ip-address-havip) 为例，云 HaVIP 与普通任意浮动 IP 不同，须关联受支持的实例/网卡范围并使用单播；其他平台参照自己的 HaVIP 说明。

| 协议/端口 | 范围与用途 |
|---|---|
| TCP 22 | 控制端到三节点，SSH/Ansible |
| TCP 8443 | 三节点及受信管理端到 HaVIP/HAProxy，统一 API 入口 |
| TCP 6443 | 三节点间及 HAProxy 到每个 API server；Pod 网络访问 API Service 后端 |
| TCP 2379、2380 | 三个控制平面间的 etcd client/peer；不要暴露公网 |
| TCP 10250 | 控制平面与节点 kubelet、必要的管理路径 |
| IP 协议 112（VRRP） | 三个主 IP 互相允许的 Keepalived 单播报文；不是 UDP/TCP 的 112 端口 |
| UDP 8472 | 三个主 IP 之间的 Flannel VXLAN，按节点精确限制 |
| Pod CIDR 双向流量 | 节点/Pod/Service 通信，涉及路由、防火墙和云策略 |
| TCP/UDP 30000–32767 | 仅业务实际采用 NodePort 时需要 |

10257/10259 默认仅控制器本机；不要因安装而随意对外开放。已有主机防火墙规则由用户处理，firewall_rules_acknowledged 只记录已处理，不自动放行。HaVIP 选主正常但 API 超时，优先区分 VRRP、VIP 云映射、8443 前端、6443 后端和三台的路由。

## 查看状态

```bash
ip -4 address
systemctl status haproxy keepalived containerd kubelet --no-pager
journalctl -u keepalived -u haproxy -u kubelet -u containerd --no-pager -n 150
sudo /usr/local/bin/kubectl --kubeconfig=/etc/kubernetes/admin.conf get nodes -o wide
sudo /usr/local/bin/kubectl --kubeconfig=/etc/kubernetes/admin.conf get --raw=/readyz?verbose
sudo /usr/local/bin/crictl ps -a
```

正常时 HaVIP 只出现在一台节点的地址列表中。HAProxy 在三台都运行，8443 与 kube-apiserver 的 6443 分开。配置在 /etc/haproxy/haproxy.cfg、/etc/keepalived/keepalived.conf。template 写入前会用本机原生二进制验证配置；此项尚需在实际 Ubuntu 目标执行，源工程本地测试没有安装这些 Linux 服务。

## 故障与部分安装

- 下载：使用本次代理版的 K8S_PREPARE_PROXY，检查具体错误 URL。当前只实测过代理访问阿里云 InRelease 的单次请求，不代表所有镜像/二进制入口都可用。
- 缺包/版本不一致：核对真实 debs/manifest.tsv 和 lock.yml 的 load_balancer_versions。不要在线 apt -f install 或混入旧单节点 Deb/lock；制作新完整包。
- VIP 多 owner：排查三个主 IP 间的 VRRP 协议 112、unicast_peer、router_id 冲突和网络分区。不要把多 owner 当高可用成功。
- VIP 单 owner 但客户端不通：检查云 HaVIP 是否关联实际实例/ENI、支持的子网/区域限制、路由与安全组。必要时从未持有 VIP 的另一节点测试 192.168.0.62:8443。
- join 失败：任务输出因包含密钥/token 被 no_log 隐藏。先在失败节点查看 kubelet/containerd 日志和 /etc/kubernetes 状态；不要公开私钥或原始 join.yml。成功标记和 admin.conf 不一致时工程会拒绝自动重试。
- etcd 仅两个或含 learner：不要把三个 Node Ready 当作三个 etcd voter 成功。核对 member list/endpoint status、etcd 日志、2379/2380 和磁盘延迟；未恢复三个 voter 前不要继续做第二个节点故障测试。
- Never 镜像缺失：检查精确原始 tag 和 k8s.io namespace，全部恢复自同一完整离线包。init/join/Flannel/smoke 均不能在线补拉。
- 内核模块/统一 cgroup v2 缺失：用匹配运行内核的 Ubuntu 安装介质/模块包补齐或回到标准内核，重启后再运行。工程不下载内核。

默认只支持固定三主拓扑。不要在部署中改变 inventory 顺序、节点名/IP、HaVIP、网段或组件版本；已有指纹会拒绝。部分 join 是否已经加入 etcd 必须先核实，不能通过删除标记来强制复跑。

## 重启与实际 HA 验收

先执行 verify.yml，再执行 failover.yml；后者通过停止当前 owner 的 HAProxy 测试 track_script 和 VIP 迁移，在 always 中恢复服务。这个测试不停止 etcd 或 kubelet。

云主机关机/断网验收应从独立管理端观察，一次只选一台，确认 VIP/API、etcd 两个幸存 voter 和业务的实际恢复。恢复该台并等三 voter 健康后才能测试下一台。若控制端就在 master1，关闭 master1 会中断控制端，所以不要用它自身的会话充当唯一验收观察点。

## 数据保全与回滚

rollback.yml 是整个三节点集群的拆除恢复，不是单个 etcd 成员的退出流程。它要求三个节点都在目标集合中，并要求 rollback_confirm 和 destroy_cluster_data 明确为 true。--limit 单台会被拒绝。

已有业务时先保存 etcd 的一致性快照、对应 PKI 和业务卷数据到受管路径之外。etcd 镜像自带 etcdctl；可从第一台正在运行的 etcd 容器对一个健康 endpoint 执行 snapshot save，文件需从容器挂载的 /var/lib/etcd 复制到独立备份位置并校验后才能拆除。不要把留在 /var/lib/etcd 内的文件当成可经受 reset 的备份。快照/应用恢复不在此基础回滚的自动范围内。

首次安装备份在 /var/lib/k8s-offline/backup/manifest.json，含原主机文件、服务开机/运行状态、swap/sysctl。原始 HAProxy/Keepalived 包配置的备份发生在离线依赖 bootstrap 后、项目覆盖其配置之前。OS Deb、Ansible venv、物料与备份保留；不尝试回滚内核或卸载系统依赖。整集群拆除时 kubeadm reset 跳过 remove-etcd-member，避免把此流程误当作保持剩余集群运行的成员移除。

若回滚因挂载/缺失二进制停止，修复现场后继续同一流程，不强删活跃挂载。完成时报告保存在 /var/lib/k8s-offline/rollback-complete.json；若需重建，先重启并把整个旧 /var/lib/k8s-offline 移到独立归档位置，再从新包建立新的备份基线。不要只删除 rollback 标记和继续复用旧备份。云 HaVIP 资源及关联仍保留，由用户控制台管理。

## 官方依据

- [kubeadm 高可用拓扑](https://v1-32.docs.kubernetes.io/docs/setup/production-environment/tools/kubeadm/ha-topology/)
- [kubeadm 高可用安装和共享证书](https://v1-32.docs.kubernetes.io/docs/setup/production-environment/tools/kubeadm/high-availability/)
- [kubeadm v1beta4 配置](https://v1-32.docs.kubernetes.io/docs/reference/config-api/kubeadm-config.v1beta4/)
- [etcd 集群状态检查](https://etcd.io/docs/v3.5/tutorials/how-to-check-cluster-status/)
