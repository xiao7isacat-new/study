# 交付检查与现场验收

交付日期 2026-10-20。本次交付是 Ubuntu 22.04 amd64 的三主源工程及物料准备流程。制作环境是 macOS；没有三台云主机访问权限，未实际安装 HAProxy/Keepalived/Kubernetes 或验证你的 HaVIP 切换。

已完成本地检查：

1. 50 项单元测试，覆盖网络/CIDR、镜像归档名称、完整性/混包拒绝、代理传递，以及三主唯一地址/HaVIP/端口冲突、接口路由、三个 etcd voter 同集群/leader/learner 和端点异常。
2. bootstrap/site/verify/failover/rollback 五个 playbook 通过 Ansible --syntax-check。临时 fixture 使用禁止部署的连接插件；假 lock/容器 ID 只存在于测试临时目录，不进入真实 artifacts。
3. 九个模板均做真实 Ansible 渲染及结构检查：kubeadm init/join、kubelet/containerd、CoreDNS、HAProxy、三份 Keepalived、跨三节点六 Pod 的烟雾测试。验证稳定端点/SAN、CA pin、Never、三个后端、单播 peers、优先级、业务调度和 systemd 启动路径。
4. 额外渲染运行时跨节点 smoke argv，检查 IP 参数分离并做 shell -n；校验 etcdctl 三端点列表。所有 shell 通过 bash -n，Python 通过 3.10 语法规则 AST。
5. 制包检查源文件 SHA256、归档内容、文档相对链接和无运行时伪造物料。

本次使用宿主 Python 3.13/Ansible-core 2.18.6，而实际离线工具链是 Ubuntu Python 3.10/Ansible-core 2.17.14。没有在最终解释器、原生 Linux 服务或真实 kubeadm/etcd 上运行这些 playbook；初次上线前应在最终完整物料和测试快照上运行检查及验收。原生 HAProxy/Keepalived 配置校验和 kubeadm config validate 已纳入安装过程，但不能声称它们已在本次本地制作中执行成功。

必须现场验收的内容：

- 在同版准备机实际全量下载，通过 Ubuntu 签名、镜像/二进制/索引 hash 和完整物料验证。已知网络证据仅为用户通过 SOCKS5 到阿里云 InRelease 的 HTTP 200。
- 确认三台云主机与 HaVIP 实际关联范围、路由、协议 112/各端口安全组；替换 inventory 示例地址。
- 断开目标公网下载能力，依次完成本地 bootstrap、三节点 bootstrap.yml、site.yml、verify.yml，确认三个预期节点/etcd voter、跨节点 Pod/Service/DNS。
- 同一配置重跑，确认不重复 init/join，不重置集群身份；检查临时 join 文件已删除，本次短时 token 已清理。
- 单独执行 failover.yml，记录真实新旧 owner 及 API 检查；逐台重启、单节点故障/恢复验收必须一次只测一台。
- 在可丢弃快照环境测试整个三节点 rollback、原始文件/服务/swap/sysctl 恢复及重建基线。不得用生产数据做首次恢复演练。

不把本地通过的测试称为实机 E2E、云平台认证、生产数据恢复保证或跨任意 Linux 发行版兼容。
