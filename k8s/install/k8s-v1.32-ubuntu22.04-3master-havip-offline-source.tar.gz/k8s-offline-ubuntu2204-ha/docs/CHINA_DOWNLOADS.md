# Ubuntu 22.04 国内下载版说明

三主默认入口已保留；配置入口是 `config/downloads.env`，仍在联网 **Ubuntu 22.04 amd64 准备机**执行 `sudo bash scripts/prepare.sh`。离线目标继续使用本地完整物料，不依赖这些服务。

## 本次报错与修复

日志中 archive.ubuntu.com/security.ubuntu.com 的 IPv6 无路由、IPv4 超时，导致索引缺失；skopeo 和 python3-venv “无候选包”是后果。工程原先自己生成临时 sources.list，所以只修改系统 sources.list 不会影响工程。

本版把全部下载入口集中配置，APT 和 curl 使用 IPv4；APT 采用独立索引目录并设置 `APT::Update::Error-Mode=any`，任一源失败即退出。APT 空 sourceparts/preferencesparts 改用真实临时空目录，消除 `/etc/apt/-/` 警告。脚本不改全局 sources.list，不关闭 GPG 或 HTTPS 验证。

## 下载服务

| 内容 | 国内入口 | 服务提供方文档 |
|---|---|---|
| Ubuntu jammy/jammy-updates/jammy-security | `https://mirrors.aliyun.com/ubuntu` | [阿里云 Ubuntu 帮助](https://developer.aliyun.com/mirror/ubuntu) |
| Ansible 及依赖 wheels | `https://mirrors.aliyun.com/pypi/simple` | [阿里云 PyPI 帮助](https://developer.aliyun.com/mirror/pypi) |
| Kubernetes、containerd、runc、CNI、crictl、Flannel 清单及 sidecar | `https://files.m.daocloud.io/<官方域名>/<原路径>` | [DaoCloud 文件加速](https://github.com/DaoCloud/public-binary-files-mirror) |
| Kubernetes、Flannel 和验收镜像 | `m.daocloud.io/<原 registry>/<原路径>:<tag>` | [DaoCloud 镜像加速](https://github.com/DaoCloud/public-image-mirror) |

三个 Ubuntu suite 均使用国内镜像，包括 security；镜像同步存在延迟。Ubuntu 仍用系统自带 archive keyring 验签，下载字节必须与签名仓库索引的 SHA256 一致。这里的三个 suite 都遵循阿里云 Ubuntu 镜像的 jammy 配置。

## 默认版本的二进制及校验下载链接

组件版本和官方原始来源见 [DOWNLOADS.md](DOWNLOADS.md)。下面均为默认版本的实际国内入口；文件内容、sidecar 都由准备脚本真实核对后写入总清单。

| 工程内路径 | 国内下载 URL |
|---|---|
| `artifacts/bin/kubeadm` | [下载](https://files.m.daocloud.io/dl.k8s.io/release/v1.32.13/bin/linux/amd64/kubeadm) |
| `artifacts/bin/kubelet` | [下载](https://files.m.daocloud.io/dl.k8s.io/release/v1.32.13/bin/linux/amd64/kubelet) |
| `artifacts/bin/kubectl` | [下载](https://files.m.daocloud.io/dl.k8s.io/release/v1.32.13/bin/linux/amd64/kubectl) |
| `artifacts/downloads/containerd.tar.gz` | [下载](https://files.m.daocloud.io/github.com/containerd/containerd/releases/download/v1.7.36/containerd-1.7.36-linux-amd64.tar.gz) |
| `artifacts/downloads/runc.amd64` | [下载](https://files.m.daocloud.io/github.com/opencontainers/runc/releases/download/v1.3.4/runc.amd64) |
| `artifacts/downloads/cni-plugins.tgz` | [下载](https://files.m.daocloud.io/github.com/containernetworking/plugins/releases/download/v1.7.1/cni-plugins-linux-amd64-v1.7.1.tgz) |
| `artifacts/downloads/crictl.tar.gz` | [下载](https://files.m.daocloud.io/github.com/kubernetes-sigs/cri-tools/releases/download/v1.32.0/crictl-v1.32.0-linux-amd64.tar.gz) |
| `artifacts/manifests/kube-flannel.yml` | [下载](https://files.m.daocloud.io/github.com/flannel-io/flannel/releases/download/v0.28.4/kube-flannel.yml) |
| `artifacts/downloads/checksums/kubeadm.sha256.txt` | [下载](https://files.m.daocloud.io/dl.k8s.io/release/v1.32.13/bin/linux/amd64/kubeadm.sha256) |
| `artifacts/downloads/checksums/kubelet.sha256.txt` | [下载](https://files.m.daocloud.io/dl.k8s.io/release/v1.32.13/bin/linux/amd64/kubelet.sha256) |
| `artifacts/downloads/checksums/kubectl.sha256.txt` | [下载](https://files.m.daocloud.io/dl.k8s.io/release/v1.32.13/bin/linux/amd64/kubectl.sha256) |
| `artifacts/downloads/checksums/containerd.tar.gz.sha256.txt` | [下载](https://files.m.daocloud.io/github.com/containerd/containerd/releases/download/v1.7.36/containerd-1.7.36-linux-amd64.tar.gz.sha256sum) |
| `artifacts/downloads/checksums/runc.amd64.sha256.txt` | [下载](https://files.m.daocloud.io/github.com/opencontainers/runc/releases/download/v1.3.4/runc.sha256sum) |
| `artifacts/downloads/checksums/cni-plugins.tgz.sha256.txt` | [下载](https://files.m.daocloud.io/github.com/containernetworking/plugins/releases/download/v1.7.1/cni-plugins-linux-amd64-v1.7.1.tgz.sha256) |
| `artifacts/downloads/checksums/crictl.tar.gz.sha256.txt` | [下载](https://files.m.daocloud.io/github.com/kubernetes-sigs/cri-tools/releases/download/v1.32.0/crictl-v1.32.0-linux-amd64.tar.gz.sha256) |

## 镜像名称与来源

不要把 `config/versions.env` 的 `IMAGE_REPOSITORY=registry.k8s.io` 改成 `m.daocloud.io`：kubeadm 需要的原始镜像名与网络传输入口分别管理。

| 原始引用（archive 和 CRI 使用） | 实际传输引用（准备机使用） |
|---|---|
| `registry.k8s.io/kube-apiserver:v1.32.13` | `m.daocloud.io/registry.k8s.io/kube-apiserver:v1.32.13` |
| `registry.k8s.io/pause:3.10` | `m.daocloud.io/registry.k8s.io/pause:3.10` |
| `ghcr.io/flannel-io/flannel:v0.28.4` | `m.daocloud.io/ghcr.io/flannel-io/flannel:v0.28.4` |
| `ghcr.io/flannel-io/flannel-cni-plugin:v1.9.1-flannel1` | `m.daocloud.io/ghcr.io/flannel-io/flannel-cni-plugin:v1.9.1-flannel1` |

其余 kubeadm 和验收镜像按同一前缀规则映射；完整原始清单见 DOWNLOADS。准备时从加速器解析 linux/amd64 digest，再按该 digest 取内容；Docker archive 仍写入原始完整 tag，离线 containerd 导入 `k8s.io` 后直接匹配 kubeadm/CNI 所需引用。不会以“换一张相似镜像并重新打标签”替代。

`artifacts/images/manifest.tsv` 会区分 `ref`（原始引用）、`mirror_ref`（实际镜像 tag）、`source`（实际镜像 @digest）、digest 与 archive SHA256。digest 解析来自加速器，未通过国外原仓库独立比对，不能把 tag 相同表述为已验证官方当前内容完全一致。

## 校验与信任边界

- Deb：Ubuntu archive keyring 签名验证 + 签名索引中的 SHA256；不使用 trusted=yes/允许未认证下载。
- wheel：HTTPS 镜像 simple 索引的 `#sha256=` 与下载内容核对；保存索引 HTML、确切镜像文件 URL、版本和 hash。准备和离线 bootstrap 的 pip 忽略其他 pip 配置，不增加国外 extra-index。
- 二进制：上游格式的 checksum sidecar 同样经文件加速器获取并核对。文件和 checksum 来自同一第三方服务，不构成独立的上游签名/身份认证。Flannel 清单无 sidecar，固定发行路径下载后记录本地 SHA（TOFU）。
- 已知固定发布信息仍见 DOWNLOADS；若需要独立供应链背书，应由你的可信联网环境复核原始签名/digest 后批准完整包 SHA。
- `downloads/manifest.tsv` 保存官方来源 URL、实际请求 URL、最终 URL、校验 URL 与验证方式。`lock.yml` 记录下载配置；修改下载配置或组件版本必须制作新包，不能混合半成品。

公共镜像可能有缓存未命中、同步延迟、排队、白名单和限流。本次核对了服务方规则及镜像白名单，没有在你的网络实际完成全量下载，不能保证每个历史版本此刻均能下载；遇到 403/404/429、超时或 hash 不符会明确失败，不自动换版本，也不自动直连国外源。服务端重定向/CDN 由服务方控制，入口域名不能保证每段物理链路都在境内。

## 使用方式

将本次国内版 tar 及其 sha256 文件放入准备机 `/opt`，使用新的空目录，不覆盖旧配置和半成品：

```bash
cd /opt
sha256sum -c k8s-v1.32-ubuntu22.04-3master-havip-offline-source.tar.gz.sha256
mkdir k8s-cn-prepare
tar -xzf k8s-v1.32-ubuntu22.04-3master-havip-offline-source.tar.gz -C k8s-cn-prepare
cd /opt/k8s-cn-prepare/k8s-offline-ubuntu2204-ha
cat config/downloads.env
sudo env K8S_PREPARE_PROXY=socks5h://172.16.0.41:8080 bash scripts/prepare.sh
sudo bash scripts/package.sh /opt/k8s-offline-ubuntu22-ha-amd64.tar.gz
```

完整包生成后按 README 转入目标机，运行本地 bootstrap、修改 inventory 和网络配置、再执行安装 playbook。**源包本身不是包含镜像和依赖的离线介质。**

准备机须具备标准 Ubuntu 22.04 自带的可信 CA/Ubuntu keyring、正确时间、基础 Python 3.10 与包管理器。当前网络通过 SOCKS5 代理访问成功，使用本次新增的 K8S_PREPARE_PROXY 参数统一配置各下载工具，具体见代理准备说明。不使用 curl -k、pip trusted-host 或关闭 apt 验签来处理证书/网络错误。

当前已确认代理可访问阿里云，具体使用与边界见 [PROXY_PREPARATION.md](PROXY_PREPARATION.md)。
