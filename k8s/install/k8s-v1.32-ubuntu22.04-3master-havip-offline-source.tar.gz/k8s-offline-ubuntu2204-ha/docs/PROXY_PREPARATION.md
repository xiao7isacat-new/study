# 使用已验证的 SOCKS5 代理准备离线包

你已在目标网络用 curl 验证：通过 `socks5h://172.16.0.41:8080` 访问阿里云 Ubuntu jammy InRelease 返回 HTTP 200。此结果说明该请求的代理路径可用；尚未验证所有二进制、PyPI wheel、registry 的实际全量传输。

## 运行本次更新版

把本次代理版源工程 tar 和校验文件复制到联网准备机的 `/opt`。在新目录解压，保留原工程和失败日志：

```bash
cd /opt
sha256sum -c k8s-v1.32-ubuntu22.04-3master-havip-offline-source.tar.gz.sha256
mkdir k8s-proxy-prepare
tar -xzf k8s-v1.32-ubuntu22.04-3master-havip-offline-source.tar.gz -C k8s-proxy-prepare
cd /opt/k8s-proxy-prepare/k8s-offline-ubuntu2204-ha
sudo env K8S_PREPARE_PROXY=socks5h://172.16.0.41:8080 bash scripts/prepare.sh
sudo bash scripts/package.sh /opt/k8s-offline-ubuntu22-ha-amd64.tar.gz
```

本命令需要本次更新的脚本；`K8S_PREPARE_PROXY` 是准备脚本新增的输入，不是所有软件天然识别的系统变量。默认 Ubuntu 和 PyPI 均使用阿里云，二进制和容器镜像使用 DaoCloud。`config/downloads.env` 仍可修改国内入口，`IMAGE_REPOSITORY=registry.k8s.io` 仍保留原运行时引用。

## 各下载工具如何使用代理

| 工具 | 处理 |
|---|---|
| APT（准备工具安装和完整 Deb 依赖下载） | 显式设置 Acquire::http::Proxy、Acquire::https::Proxy 为 socks5h；保留 Ubuntu archive keyring 验签。Ubuntu 22.04 APT 原生支持此代理协议，无需额外转接守护进程。 |
| pip | 显式传入 --proxy socks5h；先通过签名 APT 源安装准备机的 python3-socks，避免用尚不支持 SOCKS 的 pip 下载自己的 SOCKS 依赖。 |
| curl（二进制、校验文件和 wheel 索引） | 显式传入 --proxy socks5h 和空 --noproxy，忽略 curlrc；继续验证 HTTPS 证书。 |
| skopeo（解析镜像、下载 config/blob 和导出 archive） | 为所有调用单独设置大小写 HTTP_PROXY/HTTPS_PROXY，并将 socks5h 转为旧 Go transport 接受的 socks5 格式；Go SOCKS dialer 把目标主机名交给代理解析。 |

pip 的 SOCKS 支持来自 [Ubuntu jammy 的 python3-socks](https://packages.ubuntu.com/en/jammy/python/python3-socks)（基线版本 1.7.1+dfsg-1，APT 实际候选及其依赖由签名仓库决定）。只有临时准备 venv 使用 --system-site-packages，以读取系统 PySocks；pip download 本身忽略已安装包状态，依然下载 Ansible 及全部传递依赖 wheels。离线目标的 .venv 按原流程独立创建，不依赖 PySocks 或准备机的 Python 包。

代理输入只作用于联网准备进程，环境变量由 sudo env 明确传入后被子流程继承。不写入 /etc/apt/apt.conf.d、/etc/profile.d 或 systemd 服务，也不写入 lock 中的下载来源字段。代理模式清空本次准备过程的 NO_PROXY/no_proxy，避免环境中的绕过规则导致部分站点意外直连。当前集成支持不带认证信息的 socks5h/http/https 代理地址，与你提供的地址一致。

## 打包和离线安装

准备成功才运行 package.sh，检查所有 manifest/lock/SHA256 后把完整包传入离线区。离线 bootstrap 和 playbook 不需要传 K8S_PREPARE_PROXY，containerd/kubelet 也不设置代理。完整部署、验证、重启和回滚步骤继续见 README。

任一步失败都应保留完整错误；脚本不会把半成品当成功，也不盲目复用部分下载。代理到阿里云某一个 URL 成功不代表其能访问所有国内入口；实际服务限流、缓存和访问策略仍由准备时结果确认。

## 实现依据

- [Ubuntu 22.04 APT 代理文档](https://manpages.ubuntu.com/manpages/jammy/en/man1/apt-transport-http.1.html)
- [pip 代理参数](https://pip.pypa.io/en/stable/user_guide/#using-a-proxy-server)
- [Go 1.18 transport 支持的代理 scheme 和 SOCKS 处理](https://github.com/golang/go/blob/go1.18.10/src/net/http/transport.go)
- [pip 22.0.2 download 忽略已安装包状态的实现](https://github.com/pypa/pip/blob/22.0.2/src/pip/_internal/commands/download.py)
