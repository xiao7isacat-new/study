# 三主离线物料

源工程不包含大型物料或假 lock/digest。在联网 Ubuntu 22.04 amd64 上运行带代理的 prepare.sh 后生成完整物料。新增 HAProxy、Keepalived、procps 的签名 Deb 依赖闭包与实际版本锁；不接受旧单节点 topology/lock。

来源与路径见 ../docs/DOWNLOADS.md，代理见 ../docs/PROXY_PREPARATION.md；生成后才可 package.sh 并转入离线目标。
