#!/usr/bin/env python3
"""No-network source checks, real Ansible templating, and syntax-only parsing.

Requires the chosen Python to have PyYAML and ansible-core installed already.
Nothing is installed by this test. All mock bundle files and rendered outputs
are temporary and never enter the real artifacts/ directory. The installation,
verification, and rollback plays are ALWAYS invoked with --syntax-check only.
"""
import ast
import configparser
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
try:
    import tomllib
except ModuleNotFoundError:
    import tomli as tomllib  # Bundled wheel for Ubuntu 22.04 / Python 3.10


ROOT = Path(__file__).resolve().parents[1]


def check(condition, message):
    if not condition:
        raise AssertionError(message)


def command(arguments, **kwargs):
    # This guard deliberately rejects execution of a project playbook.
    if "ansible.cli.playbook" in arguments and "--syntax-check" not in arguments:
        raise RuntimeError("Validation may only syntax-check Ansible playbooks")
    subprocess.run(arguments, check=True, **kwargs)


def read_versions():
    values = {}
    for line in (ROOT / "config/versions.env").read_text().splitlines():
        if line and not line.lstrip().startswith("#"):
            key, value = line.split("=", 1)
            values[key] = value.strip().strip("\"'")
    return values


def fixture_lock():
    versions = read_versions()
    # Explicit NON-RUNNABLE fixture. No image archive or binary is fabricated.
    return {"offline_lock": {
        "schema_version": 1, "os_id": "ubuntu", "os_version": "22.04", "arch": "amd64",
        "kubernetes_version": versions["KUBERNETES_VERSION"],
        "containerd_version": versions["CONTAINERD_VERSION"], "runc_version": versions["RUNC_VERSION"],
        "cni_plugins_version": versions["CNI_PLUGINS_VERSION"], "crictl_version": versions["CRICTL_VERSION"],
        "flannel_version": versions["FLANNEL_VERSION"], "ansible_core_version": versions["ANSIBLE_CORE_VERSION"],
        "image_repository": versions["IMAGE_REPOSITORY"],
        "pause_image": versions["IMAGE_REPOSITORY"] + "/pause:3.10",
        "smoke_image": versions["SMOKE_IMAGE"], "images": [], "kubeadm_images": [],
        "validation_fixture_only": True,
        "topology":"three-control-plane-ha", "load_balancer_versions":{"haproxy":"fixture-only","keepalived":"fixture-only"},
    }}


def syntax_check(mock, environment):
    shutil.copytree(ROOT / "playbooks", mock / "playbooks")
    shutil.copytree(ROOT / "config", mock / "config")
    (mock / "artifacts").mkdir()
    (mock / "artifacts/lock.yml").write_text(json.dumps(fixture_lock(), indent=2) + "\n")
    inventory = mock / "inventory.ini"
    # If the syntax-only guard is ever accidentally removed, the nonexistent
    # connection plugin still prevents any real host or localhost execution.
    inventory.write_text("[control_plane]\n" + "".join(
        f"master{i} ansible_host=192.0.2.{i} ansible_connection=offline_validation_forbidden kube_node_ip=192.168.0.{10+i}\n" for i in range(1,4)))
    for name in ("bootstrap.yml", "site.yml", "verify.yml", "failover.yml", "rollback.yml"):
        command([sys.executable, "-m", "ansible.cli.playbook", "--syntax-check",
                 "-i", str(inventory), str(mock / "playbooks" / name)], cwd=mock, env=environment)


def render_and_validate(directory, yaml):
    # Imports occur only AFTER ANSIBLE_LOCAL_TEMP/ANSIBLE_CONFIG are isolated.
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    variables = yaml.safe_load((ROOT / "config/cluster.yml").read_text())
    variables.update(fixture_lock())
    variables.update(kube_node_ip="172.16.0.50", kubelet_resolv_conf="/run/systemd/resolve/resolv.conf",
                     smoke_image=variables["offline_lock"]["smoke_image"])
    variables["allow_control_plane_workloads"] = True
    roster=["master1","master2","master3"]
    variables.update(inventory_hostname="master1", kube_node_name="master1", kube_node_ip="192.168.0.11",
                     ha_nodes=["192.168.0.11","192.168.0.12","192.168.0.13"], ha_effective_interface="ens3",
                     groups={"control_plane":roster}, hostvars={h:{"kube_node_ip":f"192.168.0.{11+i}"} for i,h in enumerate(roster)})
    variables["hostvars"]["master1"].update(ha_join_token={"stdout":"abcdef.0123456789abcdef"},ha_ca_hash={"stdout":"a"*64})

    output = directory / "rendered"
    output.mkdir()
    loader = DataLoader()
    loader.set_basedir(str(ROOT))

    def render(name, override=None, suffix=""):
        data = dict(variables)
        data.update(override or {})
        rendered = Templar(loader=loader, variables=data).template(
            (ROOT / "playbooks/templates" / name).read_text(), fail_on_undefined=True)
        check(isinstance(rendered, str), f"Template did not render to text: {name}")
        check("{{" not in rendered and "{%" not in rendered, f"Unexpanded template: {name}")
        (output / (name.removesuffix(".j2") + suffix)).write_text(rendered)
        return rendered

    kubeadm = list(yaml.safe_load_all(render("kubeadm.yml.j2")))
    check([document["kind"] for document in kubeadm] ==
          ["InitConfiguration", "ClusterConfiguration", "KubeletConfiguration"], "Unexpected kubeadm document types")
    init, cluster, kubelet = kubeadm
    check(all(document["apiVersion"] == "kubeadm.k8s.io/v1beta4" for document in (init, cluster)),
          "kubeadm must use v1beta4")
    check(init["nodeRegistration"]["imagePullPolicy"] == "Never", "kubeadm must never pull images")
    check(init["nodeRegistration"]["taints"] == [], "HA control plane must schedule workloads")
    check(init["localAPIEndpoint"]["advertiseAddress"] == variables["kube_node_ip"], "Wrong API address")
    check(init["nodeRegistration"]["kubeletExtraArgs"] ==
          [{"name": "node-ip", "value": variables["kube_node_ip"]}], "v1beta4 extra args must use name/value list")
    check(cluster["networking"]["podSubnet"] == variables["pod_cidr"], "Wrong Pod CIDR")
    check(cluster["networking"]["serviceSubnet"] == variables["service_cidr"], "Wrong Service CIDR")
    check(cluster["kubernetesVersion"] == variables["offline_lock"]["kubernetes_version"], "Wrong Kubernetes version")
    check(kubelet["apiVersion"] == "kubelet.config.k8s.io/v1beta1" and kubelet["cgroupDriver"] == "systemd",
          "Wrong Kubelet API/cgroup configuration")
    check(kubelet["clusterDNS"] == [variables["cluster_dns"]] and kubelet["failSwapOn"] is True,
          "Kubelet DNS/swap settings do not match cluster configuration")
    tainted = list(yaml.safe_load_all(render("kubeadm.yml.j2", {"allow_control_plane_workloads": False}, ".tainted")))[0]
    check(tainted["nodeRegistration"]["taints"] ==
          [{"key": "node-role.kubernetes.io/control-plane", "effect": "NoSchedule"}], "Control-plane taint switch failed")
    custom = list(yaml.safe_load_all(render("kubeadm.yml.j2", {
        "pod_cidr": "10.200.0.0/16", "service_cidr": "10.100.0.0/16", "cluster_dns": "10.100.0.10"}, ".custom")))
    check(custom[1]["networking"]["podSubnet"] == "10.200.0.0/16" and
          custom[1]["networking"]["serviceSubnet"] == "10.100.0.0/16" and
          custom[2]["clusterDNS"] == ["10.100.0.10"], "Custom CIDR/DNS configuration did not propagate")

    runtime = tomllib.loads(render("containerd-config.toml.j2"))
    cri = runtime["plugins"]["io.containerd.grpc.v1.cri"]
    runc = cri["containerd"]["runtimes"]["runc"]
    check(runtime["version"] == 2 and cri["sandbox_image"] == variables["offline_lock"]["pause_image"],
          "containerd schema/pause image does not match lock")
    check(runc["runtime_type"] == "io.containerd.runc.v2" and runc["options"]["SystemdCgroup"] is True,
          "containerd must use runc v2 and systemd cgroups")
    check(runc["options"]["BinaryName"] == "/usr/local/sbin/runc", "runc binary path mismatch")
    check(cri["cni"]["bin_dir"] == "/opt/cni/bin" and cri["cni"]["conf_dir"] == "/etc/cni/net.d",
          "containerd CNI paths mismatch")

    dns = yaml.safe_load(render("coredns.yml.j2", {"coredns_upstream_dns": []}))
    corefile = dns["data"]["Corefile"]
    check("kubernetes cluster.local" in corefile and "forward ." not in corefile and "/etc/resolv.conf" not in corefile,
          "Fully isolated default CoreDNS must not depend on host/public upstream DNS")
    upstream_dns = yaml.safe_load(render("coredns.yml.j2", {"coredns_upstream_dns": ["172.16.0.1"]}, ".upstream"))
    check("forward . 172.16.0.1" in upstream_dns["data"]["Corefile"], "Explicit LAN DNS resolver did not propagate")

    for name, executable in (("kubelet.service.j2", "/usr/local/bin/kubelet"),
                             ("containerd.service.j2", "/usr/local/bin/containerd")):
        unit = render(name)
        matches = re.findall(r'^Environment="PATH=([^\"]+)"$', unit, flags=re.MULTILINE)
        check(len(matches) == 1 and {"/usr/local/sbin", "/usr/local/bin", "/usr/sbin", "/usr/bin"} <=
              set(matches[0].split(":")), f"Explicit executable PATH missing from {name}")
        parsed = configparser.ConfigParser(interpolation=None, strict=False)
        parsed.read_string(unit)
        check(parsed["Service"]["ExecStart"].split()[0] == executable, f"Wrong ExecStart in {name}")
        check(parsed["Install"]["WantedBy"] == "multi-user.target", f"Boot enablement missing from {name}")
    smoke = list(yaml.safe_load_all(render("smoke-test.yml.j2")))
    pods = [document for document in smoke if document["kind"] == "Pod"]
    check(len(pods) == 6 and any(document["kind"] == "Service" for document in smoke), "Incomplete network smoke test")
    for pod in pods:
        check(pod["spec"]["nodeSelector"]["kubernetes.io/hostname"] in variables["groups"]["control_plane"],
              "Smoke test node selector mismatch")
        for container in pod["spec"]["containers"]:
            check(container["imagePullPolicy"] == "Never" and container["image"] == variables["smoke_image"],
                  "Smoke images must be locked and never pulled")
    check(cluster["controlPlaneEndpoint"] == "192.168.0.62:8443", "Stable endpoint not present in kubeadm")
    check(set(variables["ha_nodes"] + [variables["ha_vip"]]) <= set(cluster["apiServer"]["certSANs"]), "API SANs missing VIP or peers")
    for idx,host in enumerate(roster):
        override={"inventory_hostname":host,"kube_node_name":host,"kube_node_ip":variables["ha_nodes"][idx],"kubelet_resolv_conf":"/etc/resolv.conf"}
        join=yaml.safe_load(render("join.yml.j2",override,"."+host))
        check(join["kind"] == "JoinConfiguration" and join["apiVersion"] == "kubeadm.k8s.io/v1beta4", "Join API mismatch")
        check(join["nodeRegistration"]["imagePullPolicy"] == "Never" and join["nodeRegistration"]["taints"] == [], "Join must preload images and allow workloads")
        check(join["controlPlane"]["localAPIEndpoint"]["advertiseAddress"] == override["kube_node_ip"], "Join uses wrong node address")
        discovery=join["discovery"]["bootstrapToken"]
        check(discovery["apiServerEndpoint"] == "192.168.0.62:8443" and discovery["caCertHashes"] == ["sha256:"+"a"*64], "Join endpoint or CA pin mismatch")
        check(not discovery.get("unsafeSkipCAVerification",False), "Join must pin the CA")
        kp=render("keepalived.conf.j2",override,"."+host)
        peers=kp.split("unicast_peer {",1)[1].split("}",1)[0].split()
        check(set(peers) == set(variables["ha_nodes"])-{override["kube_node_ip"]}, "Unicast peers must be exactly the other two nodes")
        check("state BACKUP" in kp and "nopreempt" in kp and "192.168.0.62/32 dev ens3" in kp, "Keepalived ownership configuration mismatch")
        check("priority "+str(150-10*idx) in kp and "check_haproxy" in kp, "Keepalived priority/health tracking missing")
    haproxy=render("haproxy.cfg.j2")
    check("bind 0.0.0.0:8443" in haproxy and "mode tcp" in haproxy and "option tcp-check" in haproxy, "HAProxy must forward TCP on separate 8443")
    check(all(f"server {h} {variables['ha_nodes'][i]}:6443 check" in haproxy for i,h in enumerate(roster)), "HAProxy must include all three backend API servers")
    check({p["spec"]["nodeSelector"]["kubernetes.io/hostname"] for p in pods} == set(roster), "Cross-node smoke must cover all masters")
    # Render the executable smoke argv without executing it: IP arguments stay separate.
    smoke_tasks=yaml.safe_load((ROOT / "playbooks/tasks/smoke_ha.yml").read_text())
    smoke_task=next(t for t in smoke_tasks[-1]["block"] if t.get("name", "").startswith("From every client"))
    smoke_vars=dict(variables, item="0", ha_server_ips=["10.244.0.2","10.244.1.2","10.244.2.2"])
    argv=Templar(loader=loader,variables=smoke_vars).template(smoke_task["ansible.builtin.command"]["argv"],fail_on_undefined=True)
    check(isinstance(argv,list) and argv[-3:] == smoke_vars["ha_server_ips"],"Smoke argv must pass all three server IPs as separate shell arguments")
    command(["bash","-n","-c",argv[argv.index("-ec")+1]])
    # Check the generated etcd endpoint list, preserving each HTTPS peer URL.
    verify_tasks=yaml.safe_load((ROOT / "playbooks/tasks/verify_ha.yml").read_text())
    etcd_task=next(t for t in verify_tasks[-1]["block"] if t.get("name", "").startswith("Build the etcdctl prefix"))
    etcd_vars=dict(variables,ha_etcd_container={"stdout":"nonrunnable-container-fixture"})
    prefix=Templar(loader=loader,variables=etcd_vars).template(etcd_task["ansible.builtin.set_fact"]["ha_etcdctl"],fail_on_undefined=True)
    check("--endpoints="+",".join("https://"+ip+":2379" for ip in variables["ha_nodes"]) in prefix,"Wrong etcd endpoint list")
    print("Real Ansible template rendering and parsed kubeadm/TOML/CoreDNS/systemd/smoke assertions passed.", flush=True)


def main():
    for script in sorted((ROOT / "scripts").glob("*.sh")) + [ROOT / "tests/check.sh"]:
        command(["bash", "-n", str(script)])
    for directory in (ROOT / "scripts", ROOT / "tests"):
        for path in sorted(directory.glob("*.py")):
            ast.parse(path.read_text(), filename=str(path), feature_version=(3, 10))
    print("Shell and Python syntax checks passed.", flush=True)
    try:
        import yaml
    except ImportError:
        sys.exit("The selected Python needs existing PyYAML and ansible-core; no dependencies are downloaded by this test.")
    work = ROOT / "work"
    work.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="validation-", dir=work) as temporary:
        directory = Path(temporary)
        local_temp = directory / "ansible-local"
        local_temp.mkdir()
        config = directory / "ansible.cfg"
        config.write_text("[defaults]\nretry_files_enabled=False\ninterpreter_python=" + sys.executable +
                          "\nlocal_tmp=" + str(local_temp) + "\n[privilege_escalation]\nbecome=False\n")
        environment = os.environ.copy()
        environment.update(ANSIBLE_CONFIG=str(config), ANSIBLE_LOCAL_TEMP=str(local_temp),
                           ANSIBLE_NOCOLOR="1", ANSIBLE_RETRY_FILES_ENABLED="False",
                           PYTHONDONTWRITEBYTECODE="1")
        os.environ.update({key: environment[key] for key in ("ANSIBLE_CONFIG", "ANSIBLE_LOCAL_TEMP")})
        try:
            import ansible.release
        except ImportError:
            sys.exit("The selected Python needs existing ansible-core; this test never installs dependencies.")
        print(f"Validation interpreter: {sys.executable}; ansible-core {ansible.release.__version__}", flush=True)
        command([sys.executable, str(ROOT / "tests/test_helpers.py")], cwd=ROOT, env=environment)
        mock = directory / "mock-project"
        mock.mkdir()
        syntax_check(mock, environment)
        render_and_validate(directory, yaml)
    print("All local checks passed. No installation/verification/rollback play was executed; no network was used.", flush=True)


if __name__ == "__main__":
    main()
