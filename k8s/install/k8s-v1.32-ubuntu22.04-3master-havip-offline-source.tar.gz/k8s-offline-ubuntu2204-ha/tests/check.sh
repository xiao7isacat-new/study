#!/usr/bin/env bash
# Pure/local validation. No artifact download or host provisioning is performed.
set -Eeuo pipefail
test_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
exec "${PYTHON:-python3}" "$test_root/tests/validate_project.py"
