"""Pure/local tests. No networking, package installation, or host configuration changes."""
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest import mock
import yaml

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
import manifest
import node_preflight
import prepare_images
import render_flannel
import ha_checks
import download_sources


def addresses(extra=None):
    return [{'ifname': 'eth0', 'flags': ['UP'], 'addr_info': [
        {'family': 'inet', 'local': '172.16.0.50', 'prefixlen': 24}]}] + (extra or [])


class NetworkChecks(unittest.TestCase):
    def check(self, **kwargs):
        args = dict(node_ip='172.16.0.50', pod_cidr='10.244.0.0/16',
                    service_cidr='10.96.0.0/12', cluster_dns='10.96.0.10',
                    addresses=addresses(), routes=[{'dst': 'default', 'dev': 'eth0'}])
        args.update(kwargs)
        return node_preflight.check(**args)

    def test_valid_node(self):
        self.assertEqual(self.check()['interface'], 'eth0')

    def test_missing_local_ip(self):
        with self.assertRaises(ValueError):
            self.check(node_ip='172.16.0.99')

    def test_node_interface_down(self):
        links = addresses()
        links[0]['flags'] = []
        with self.assertRaises(ValueError):
            self.check(addresses=links)

    def test_overlap_pod_service(self):
        with self.assertRaises(ValueError):
            self.check(pod_cidr='10.96.0.0/16')

    def test_conflicting_host_route(self):
        with self.assertRaises(ValueError):
            self.check(routes=[{'dst': '10.0.0.0/8', 'dev': 'tun0'}])

    def test_wrong_dns_service(self):
        with self.assertRaises(ValueError):
            self.check(cluster_dns='10.96.0.11')

    def test_oversized_service_network(self):
        with self.assertRaises(ValueError):
            self.check(service_cidr='10.0.0.0/8', cluster_dns='10.0.0.10')

    def test_managed_rerun_own_cni(self):
        links = addresses([{'ifname': 'cni0', 'flags': ['UP'], 'addr_info': [
            {'family': 'inet', 'local': '10.244.0.1', 'prefixlen': 24}]}])
        self.assertEqual(self.check(addresses=links, routes=[{'dst': '10.244.0.0/24', 'dev': 'cni0'}],
                                    managed=True)['interface'], 'eth0')

    def test_unmanaged_cni_rejected(self):
        with self.assertRaises(ValueError):
            self.check(routes=[{'dst': '10.244.0.0/24', 'dev': 'cni0'}])

    def test_changed_network_together(self):
        result = self.check(pod_cidr='10.200.0.0/16', service_cidr='10.100.0.0/16', cluster_dns='10.100.0.10')
        self.assertEqual(result['cluster_dns'], '10.100.0.10')


class FlannelChecks(unittest.TestCase):
    def setUp(self):
        self.docs = list(yaml.safe_load_all((ROOT / 'tests/fixtures/flannel-upstream.yml').read_text()))

    def test_real_release_renders_offline(self):
        upstream = set(prepare_images.walk_images(self.docs))
        result = render_flannel.render(copy.deepcopy(self.docs), '10.200.0.0/16', '172.16.0.50')
        self.assertEqual(set(prepare_images.walk_images(result)), upstream)
        config, = [d for d in result if d.get('kind') == 'ConfigMap']
        self.assertEqual(json.loads(config['data']['net-conf.json'])['Network'], '10.200.0.0/16')
        ds, = [d for d in result if d.get('kind') == 'DaemonSet']
        spec = ds['spec']['template']['spec']
        self.assertTrue(all(c['imagePullPolicy'] == 'Never' for c in spec['containers'] + spec['initContainers']))
        self.assertIn('--iface=172.16.0.50', spec['containers'][0]['args'])

    def test_changed_manifest_layout_fails(self):
        with self.assertRaises(ValueError):
            render_flannel.render([], '10.244.0.0/16', 'eth0')

    def test_empty_iface_fails(self):
        with self.assertRaises(ValueError):
            render_flannel.render(self.docs, '10.244.0.0/16', '')


class InventoryChecks(unittest.TestCase):
    def test_checksum_sidecar_plain_and_gnu(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'checksum'
            digest = 'a' * 64
            for content in [digest, digest + '  ./runc.amd64\n', digest + ' *runc.amd64\n']:
                path.write_text(content)
                self.assertEqual(manifest.checksum_from_file(path, 'runc.amd64'), digest)

    def test_checksum_missing_asset_fails(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'checksum'
            path.write_text('a' * 64 + '  other\n')
            with self.assertRaises(RuntimeError):
                manifest.checksum_from_file(path, 'runc.amd64')

    def test_registry_repository_with_port(self):
        self.assertEqual(prepare_images.repository('registry.example:5000/team/image:v1'), 'registry.example:5000/team/image')

    def test_select_amd64_digest_and_validate_config(self):
        digest = 'sha256:' + 'b' * 64
        calls = []

        def fake(args):
            calls.append(args)
            if '--raw' in args:
                return json.dumps({'manifests': [
                    {'digest': 'sha256:' + 'c' * 64, 'platform': {'os': 'linux', 'architecture': 'arm64'}},
                    {'digest': digest, 'platform': {'os': 'linux', 'architecture': 'amd64'}}]}).encode()
            return b'{"os":"linux","architecture":"amd64"}'

        with mock.patch.object(prepare_images, 'command', side_effect=fake):
            self.assertEqual(prepare_images.image_leaf('registry.example:5000/image:v1'),
                             (digest, 'registry.example:5000/image@' + digest))
        self.assertIn('@sha256:', calls[-1][-1])


class BundleChecks(unittest.TestCase):
    def create(self, base):
        root = base / 'artifacts'
        (base / 'config').mkdir()
        (base / 'config/versions.env').write_text('KUBERNETES_VERSION=v1.32.13\n')
        required = ['bin/kubeadm', 'bin/kubelet', 'bin/kubectl', 'downloads/containerd.tar.gz',
                    'downloads/runc.amd64', 'downloads/cni-plugins.tgz', 'downloads/crictl.tar.gz',
                    'manifests/kube-flannel.yml', 'debs/manifest.tsv', 'wheels/requirements.lock',
                    'images/test.tar']
        for relative in required:
            file = root / relative
            file.parent.mkdir(parents=True, exist_ok=True)
            file.write_bytes(b'fixture only\n')
        (root / 'versions.env').write_bytes((base / 'config/versions.env').read_bytes())
        ref = 'registry.k8s.io/pause:3.10'
        data = {'schema_version': 1, 'os_id': 'ubuntu', 'os_version': '22.04', 'arch': 'amd64',
                'kubeadm_images': [ref], 'smoke_image': ref, 'pause_image': ref,
                'topology':'three-control-plane-ha', 'load_balancer_versions':{'haproxy':'fixture-only','keepalived':'fixture-only'},
                'images': [{'ref': ref, 'archive': 'images/test.tar', 'digest': 'sha256:' + 'a' * 64,
                            'archive_sha256': manifest.sha(root / 'images/test.tar')}]}
        (root / 'lock.yml').write_text(json.dumps({'offline_lock': data}))
        manifest.sums(root)
        return root

    def test_complete_fixture_verifies(self):
        with tempfile.TemporaryDirectory() as directory:
            manifest.verify(self.create(Path(directory)))

    def test_ubuntu_2404_lock_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root = self.create(Path(directory))
            lock = json.loads((root / 'lock.yml').read_text())
            lock['offline_lock']['os_version'] = '24.04'
            (root / 'lock.yml').write_text(json.dumps(lock))
            manifest.sums(root)
            with self.assertRaisesRegex(RuntimeError, 'Unsupported lock schema/platform'):
                manifest.verify(root)

    def test_tampered_artifact_fails(self):
        with tempfile.TemporaryDirectory() as directory:
            root = self.create(Path(directory))
            (root / 'bin/kubeadm').write_text('corrupt')
            with self.assertRaises(RuntimeError):
                manifest.verify(root)

    def test_extra_artifact_fails(self):
        with tempfile.TemporaryDirectory() as directory:
            root = self.create(Path(directory))
            (root / 'extra').write_text('extra')
            with self.assertRaises(RuntimeError):
                manifest.verify(root)

    def test_version_change_fails(self):
        with tempfile.TemporaryDirectory() as directory:
            root = self.create(Path(directory))
            (root.parent / 'config/versions.env').write_text('KUBERNETES_VERSION=v1.32.12\n')
            with self.assertRaises(RuntimeError):
                manifest.verify(root)

    def test_single_node_bundle_rejected_by_ha_project(self):
        with tempfile.TemporaryDirectory() as directory:
            root = self.create(Path(directory))
            data = json.loads((root / 'lock.yml').read_text())
            data['offline_lock'].pop('topology')
            data['offline_lock'].pop('load_balancer_versions')
            (root / 'lock.yml').write_text(json.dumps(data))
            manifest.sums(root)
            with self.assertRaisesRegex(RuntimeError, 'HA bundle'):
                manifest.verify(root)

    def test_download_config_change_fails(self):
        with tempfile.TemporaryDirectory() as directory:
            root = self.create(Path(directory))
            config = root.parent / 'config/downloads.env'
            config.write_text('mirror policy fixture\n')
            (root / 'downloads.env').write_bytes(config.read_bytes())
            data = json.loads((root / 'lock.yml').read_text())
            data['offline_lock']['download_sources'] = {'fixture_only': True}
            (root / 'lock.yml').write_text(json.dumps(data))
            manifest.sums(root)
            config.write_text('changed mirror policy\n')
            with self.assertRaisesRegex(RuntimeError, 'downloads.env changed'):
                manifest.verify(root)


class DomesticDownloadChecks(unittest.TestCase):
    def setUp(self):
        self.environment = mock.patch.dict('os.environ', {
            **download_sources.DEFAULTS,
            'OFFLINE_APT_MIRROR': 'https://mirrors.tuna.tsinghua.edu.cn/ubuntu',
            'OFFLINE_APT_SECURITY_MIRROR': 'https://mirrors.tuna.tsinghua.edu.cn/ubuntu',
            'OFFLINE_PYPI_INDEX': 'https://pypi.tuna.tsinghua.edu.cn/simple',
        })
        self.environment.start()
        self.addCleanup(self.environment.stop)

    def test_binary_and_checksum_both_use_gateway(self):
        url = 'https://dl.k8s.io/release/v1.32.13/bin/linux/amd64/kubeadm'
        self.assertEqual(download_sources.file_url(url),
                         'https://files.m.daocloud.io/dl.k8s.io/release/v1.32.13/bin/linux/amd64/kubeadm')
        self.assertEqual(download_sources.file_url(url + '.sha256'),
                         download_sources.file_url(url) + '.sha256')

    def test_unencrypted_mirror_rejected(self):
        with mock.patch.dict('os.environ', {'OFFLINE_APT_MIRROR': 'http://mirror.example/ubuntu'}):
            with self.assertRaises(ValueError):
                download_sources.settings()

    def test_apt_rejects_lookalike_host_and_wrong_prefix(self):
        self.assertTrue(download_sources.apt_url_allowed(
            'https://mirrors.tuna.tsinghua.edu.cn/ubuntu/pool/main/x/example.deb'))
        self.assertFalse(download_sources.apt_url_allowed(
            'https://mirrors.tuna.tsinghua.edu.cn.attacker.example/ubuntu/pool/example.deb'))
        self.assertFalse(download_sources.apt_url_allowed(
            'https://mirrors.tuna.tsinghua.edu.cn/ubuntu-other/pool/example.deb'))

    def test_wheel_uses_mirror_relative_link_and_hash(self):
        index = download_sources.wheel_index_url('Example_Package')
        self.assertEqual(index, 'https://pypi.tuna.tsinghua.edu.cn/simple/example-package/')
        digest = 'a' * 64
        html = '<a href="../../packages/example.whl#sha256=' + digest + '">example.whl</a>'
        self.assertEqual(download_sources.wheel_record(html, index, 'example.whl', digest),
                         'https://pypi.tuna.tsinghua.edu.cn/packages/example.whl')

    def test_wheel_checksum_mismatch_rejected(self):
        html = '<a href="/packages/example.whl#sha256=' + 'b' * 64 + '">wheel</a>'
        with self.assertRaisesRegex(RuntimeError, 'SHA256 mismatch'):
            download_sources.wheel_record(html, download_sources.wheel_index_url('example'), 'example.whl', 'a' * 64)

    def test_wheel_external_origin_rejected(self):
        html = '<a href="https://files.pythonhosted.org/packages/example.whl#sha256=' + 'a' * 64 + '">wheel</a>'
        with self.assertRaisesRegex(RuntimeError, 'outside the configured mirror'):
            download_sources.wheel_record(html, download_sources.wheel_index_url('example'), 'example.whl', 'a' * 64)

    def test_image_copy_uses_mirror_but_archives_original_tags(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / 'manifests').mkdir()
            (root / 'images').mkdir()
            original = 'registry.k8s.io/pause:3.10'
            (root / 'manifests/kubeadm-images.txt').write_text(original + '\n')
            (root / 'manifests/kube-flannel.yml').write_bytes(
                (ROOT / 'tests/fixtures/flannel-upstream.yml').read_bytes())
            digest = 'sha256:' + 'c' * 64
            copied = []

            def copy_image(args, check, env):
                copied.append(args)
                # Locate by the fixed archive name rather than a registry-port split.
                path = root / 'images' / args[-1].split('/images/', 1)[1].split('.tar:', 1)[0]
                Path(str(path) + '.tar').write_bytes(b'non-runnable image archive fixture')

            with mock.patch.dict('os.environ', {'SMOKE_IMAGE': original}), \
                    mock.patch.object(prepare_images, 'image_leaf', side_effect=lambda ref: (digest, prepare_images.repository(ref) + '@' + digest)), \
                    mock.patch.object(prepare_images.subprocess, 'run', side_effect=copy_image), \
                    mock.patch.object(prepare_images, 'command', return_value=b'{"Os":"linux","Architecture":"amd64"}'):
                prepare_images.main(root)
            records = json.loads((root / 'images/manifest.json').read_text())
            for item, args in zip(records, copied):
                self.assertTrue(item['source'].startswith('m.daocloud.io/'))
                self.assertEqual(item['mirror_ref'], 'm.daocloud.io/' + item['ref'])
                self.assertTrue(args[-1].endswith(':' + item['ref']))
                self.assertIn('docker://m.daocloud.io/', args[-2])
            self.assertIn(original, [item['ref'] for item in records])


class PreparationProxyChecks(unittest.TestCase):
    def setUp(self):
        self.proxy = 'socks5h://127.0.0.1:18080'
        self.environment = mock.patch.dict('os.environ', {'K8S_PREPARE_PROXY': self.proxy})
        self.environment.start()
        self.addCleanup(self.environment.stop)

    def test_go_transport_uses_supported_scheme_and_clears_bypass(self):
        with mock.patch.dict('os.environ', {'NO_PROXY': '*', 'no_proxy': '*', 'HTTPS_PROXY': 'http://invalid.example:1'}):
            result = download_sources.skopeo_environment()
            self.assertEqual(result['HTTPS_PROXY'], 'socks5://127.0.0.1:18080')
            self.assertEqual(result['https_proxy'], result['HTTPS_PROXY'])
            self.assertEqual(result['NO_PROXY'], '')
            self.assertEqual(result['no_proxy'], '')
            self.assertEqual(os.environ['NO_PROXY'], '*')

    def test_curl_explicit_proxy_survives_existing_bypass(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'payload'

            def fake(args, text):
                self.assertEqual(args[:2], ['curl', '-q'])
                self.assertEqual(args[args.index('--proxy') + 1], self.proxy)
                self.assertEqual(args[args.index('--noproxy') + 1], '')
                self.assertNotIn('--insecure', args)
                Path(args[args.index('--output') + 1]).write_bytes(b'proxy transport fixture')
                return 'https://mirror.example/payload'

            with mock.patch.object(manifest.subprocess, 'check_output', side_effect=fake):
                self.assertEqual(manifest.download('https://mirror.example/payload', path),
                                 'https://mirror.example/payload')
            self.assertEqual(path.read_bytes(), b'proxy transport fixture')

    def test_apt_and_pip_receive_explicit_proxy_options(self):
        output = subprocess.check_output([
            'bash', '-c', 'source "$1"; load_download_sources >/dev/null; '
            'declare -p apt_proxy_args pip_proxy_args; printf "bypass=%s" "$no_proxy"',
            'proxy-test', str(ROOT / 'scripts/common.sh')], text=True)
        self.assertIn('Acquire::http::Proxy=' + self.proxy, output)
        self.assertIn('Acquire::https::Proxy=' + self.proxy, output)
        self.assertIn('--proxy', output)
        self.assertTrue(output.endswith('bypass='))

    def test_proxy_not_in_download_sources_lock_metadata(self):
        self.assertNotIn(self.proxy, json.dumps(download_sources.settings()))
        self.assertNotIn('K8S_PREPARE_PROXY', download_sources.settings())

    def test_unsupported_or_authenticated_proxy_rejected(self):
        for value in ['socks5://127.0.0.1:1080', 'socks5h://user:password@127.0.0.1:1080',
                      'socks5h://127.0.0.1', 'https://127.0.0.1:8080/path']:
            with self.subTest(value=value), mock.patch.dict('os.environ', {'K8S_PREPARE_PROXY': value}):
                with self.assertRaises(ValueError):
                    download_sources.prepare_proxy()

    def test_empty_proxy_keeps_direct_mode_unchanged(self):
        with mock.patch.dict('os.environ', {'K8S_PREPARE_PROXY': ''}):
            self.assertEqual(download_sources.curl_proxy_args(), [])
            self.assertEqual(download_sources.skopeo_environment(), dict(os.environ))

    def test_http_proxy_needs_no_socks_scheme_conversion(self):
        with mock.patch.dict('os.environ', {'K8S_PREPARE_PROXY': 'http://127.0.0.1:18080'}):
            self.assertEqual(download_sources.skopeo_environment()['HTTPS_PROXY'], 'http://127.0.0.1:18080')



class HaTopologyChecks(unittest.TestCase):
    def config(self):
        return dict(nodes=['192.168.0.11','192.168.0.12','192.168.0.13'], names=['master1','master2','master3'],
                    vip='192.168.0.62',port=8443,prefix=32,router_id=62,pod_cidr='10.244.0.0/16',service_cidr='10.96.0.0/12')

    def test_valid_three_master_configuration(self):
        self.assertEqual(ha_checks.topology(self.config())['endpoint'],'192.168.0.62:8443')

    def test_documentation_addresses_rejected(self):
        data=self.config();data['nodes'][0]='192.0.2.11'
        with self.assertRaisesRegex(ValueError,'documentation'):ha_checks.topology(data)

    def test_duplicate_node_or_vip_rejected(self):
        data=self.config();data['nodes'][1]=data['nodes'][0]
        with self.assertRaises(ValueError):ha_checks.topology(data)
        data=self.config();data['vip']=data['nodes'][0]
        with self.assertRaises(ValueError):ha_checks.topology(data)

    def test_api_port_conflict_rejected(self):
        data=self.config();data['port']=6443
        with self.assertRaisesRegex(ValueError,'distinct frontend'):ha_checks.topology(data)

    def test_vip_overlap_with_pod_network_rejected(self):
        data=self.config();data['pod_cidr']='192.168.0.0/16'
        with self.assertRaisesRegex(ValueError,'overlap'):ha_checks.topology(data)

    def test_wrong_count_or_name_rejected(self):
        data=self.config();data['nodes'].pop()
        with self.assertRaises(ValueError):ha_checks.topology(data)
        data=self.config();data['names'][0]='MASTER_1'
        with self.assertRaises(ValueError):ha_checks.topology(data)

    def test_interface_route_mismatch_rejected(self):
        replies=[json.dumps([{'ifname':'ens3','flags':['UP'],'addr_info':[{'family':'inet','local':'192.168.0.11'}]}]),
                 json.dumps([{'dev':'tun0'}])]
        with mock.patch.object(ha_checks.subprocess,'check_output',side_effect=replies):
            with self.assertRaisesRegex(ValueError,'route'):ha_checks.local('192.168.0.11','192.168.0.62','ens3')


class HaEtcdChecks(unittest.TestCase):
    def data(self):
        members={'members':[{'ID':i,'name':'master'+str(i),'isLearner':False} for i in (1,2,3)]}
        status=[{'Endpoint':f'https://192.168.0.{10+i}:2379','Status':{'header':{'cluster_id':7,'member_id':i},'leader':1}} for i in (1,2,3)]
        return status,members

    def test_three_voters_share_one_cluster_and_leader(self):
        states,members=self.data()
        self.assertEqual(ha_checks.etcd(states,members,['master1','master2','master3'])['healthy_leader'],1)

    def test_learner_cannot_count_as_third_voter(self):
        states,members=self.data();members['members'][2]['isLearner']=True
        with self.assertRaisesRegex(ValueError,'voting'):ha_checks.etcd(states,members,['master1','master2','master3'])

    def test_mixed_etcd_clusters_rejected(self):
        states,members=self.data();states[2]['Status']['header']['cluster_id']=99
        with self.assertRaisesRegex(ValueError,'same three-member'):ha_checks.etcd(states,members,['master1','master2','master3'])

    def test_missing_or_dead_leader_rejected(self):
        states,members=self.data()
        for item in states:item['Status']['leader']=0
        with self.assertRaisesRegex(ValueError,'live leader'):ha_checks.etcd(states,members,['master1','master2','master3'])

    def test_missing_member_or_duplicate_endpoint_rejected(self):
        states,members=self.data();members['members'].pop()
        with self.assertRaises(ValueError):ha_checks.etcd(states,members,['master1','master2','master3'])
        states,members=self.data();states[2]['Endpoint']=states[0]['Endpoint']
        with self.assertRaisesRegex(ValueError,'distinct endpoints'):ha_checks.etcd(states,members,['master1','master2','master3'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
